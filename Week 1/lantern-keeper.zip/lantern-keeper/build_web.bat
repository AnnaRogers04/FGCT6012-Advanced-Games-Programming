@echo off
REM Usage: build_web.bat C:\raylib-6.0   (run C:\emsdk\emsdk_env.bat first)
if "%~1"=="" goto usage
if not exist web mkdir web
call emcc main.c -o web\index.html -Os -Wall -std=c99 -I"%~1\src" -L"%~1\src" -lraylib.web -DPLATFORM_WEB -s USE_GLFW=3 -s ASYNCIFY -s FETCH=1 -s ALLOW_MEMORY_GROWTH=1 --shell-file shell.html --preload-file music.wav --preload-file rain.wav
if errorlevel 1 goto fail
echo.
echo Built! Open http://localhost:8000 in your browser. Press Ctrl+C here to stop the server.
cd web
py -m http.server 8000
goto end
:usage
echo Usage: build_web.bat C:\path\to\raylib
goto end
:fail
echo BUILD FAILED - see the errors above.
:end
