#!/bin/bash
# Builds the web version into ./web and serves it at http://localhost:8000
# Usage:  ./build_web.sh /path/to/raylib
# (run `source /path/to/emsdk/emsdk_env.sh` first so `emcc` works)
set -e
RAYLIB="${1:?Give the path to your raylib folder, e.g. ./build_web.sh ~/raylib}"
LIB="-lraylib.web"
[ -f "$RAYLIB/src/libraylib.web.a" ] || LIB="-lraylib"

mkdir -p web
emcc main.c -o web/index.html \
  -Os -Wall -std=c99 \
  -I"$RAYLIB/src" -L"$RAYLIB/src" $LIB \
  -DPLATFORM_WEB \
  -s USE_GLFW=3 -s ASYNCIFY -s FETCH=1 -s ALLOW_MEMORY_GROWTH=1 \
  --shell-file shell.html --preload-file music.wav --preload-file rain.wav

echo "Built! Open http://localhost:8000"
cd web && python3 -m http.server 8000
