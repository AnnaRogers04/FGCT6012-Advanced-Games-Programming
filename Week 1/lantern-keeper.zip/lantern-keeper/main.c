// =====================================================================
//  THE LANTERN KEEPER  -  pixel-art horror micro-game (Raylib, web build)
// =====================================================================
//  You are a hooded figure alone in a haunted graveyard, holding a
//  lantern up to the night. Glowing SOULS fall from the sky - catch them
//  in your lantern light for points. SKULLS and BATS fall too - touch
//  those and you lose a flame. Lose all your flames and the dead claim you.
//
//  POWER-UPS fall occasionally. Catch them in your lantern light:
//    Heart   - restores one flame
//    Shield  - blocks the next hit
//    Magnet  - pulls nearby souls toward your lantern (10s)
//    Sun     - wider lantern light, easier catching (10s)
//    Hourglass - everything falls at half speed (7s)
//
//  MODES: press H on the title screen (or game over screen).
//    NORMAL - 3 flames, a fair night.
//    HARD   - 2 flames, faster and more frequent hazards, gale-force wind,
//             power-ups are rarer, but souls are worth DOUBLE. Blood moon!
//
//  THE WEB REQUEST: when the game starts it asks a real weather API
//  (Open-Meteo) what the weather is outside RIGHT NOW. That changes the
//  night, both how it looks and how it plays:
//
//    Clear night - the moon is out. Souls are worth double.
//    Overcast    - the moon hides. Normal rules.
//    Rain        - the ground is slick grave mud: you slide.
//    Snow        - a deathly hush: you wade slowly, things drift down.
//    Storm       - the dead are restless: fast, frequent hazards.
//    Wind        - the real wind speed/direction pushes the falling things
//                  sideways, and nudges you gently. (Arrows >> or << in the
//                  weather panel show which way it blows.)
//
//  HOW THE PIXEL ART WORKS
//    The game is drawn onto a tiny 400x300 canvas (a "render texture"),
//    then stretched to the 800x600 window with no smoothing. That is what
//    makes every pixel look big and chunky. All the sprites (the keeper,
//    skulls, bats, souls, tombstones...) are small pictures typed out as
//    text below - each letter is one pixel colour. No image files needed!
//
//    The game LOGIC still uses 800x600 numbers (speeds, hitboxes...).
//    Anything we draw converts them to the small canvas with V().
//
//  HOW THE FILE IS LAID OUT (read top to bottom):
//    1. Settings you can tweak
//    2. Data types (structs) that hold the game's information
//    3. Pixel art sprites
//    4. Weather request (the "web request" part)
//    5. Game logic (Update functions)
//    6. Drawing
//    7. Frame() - runs every frame, and main() - starts everything
//
//  Controls: A/D or Left/Right = move, SPACE = start/restart,
//            H = switch mode, P = pause,
//            1-5 = preview a weather type, R = re-fetch real weather
// =====================================================================

#include "raylib.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

// These headers only exist when compiling with Emscripten (the web build).
#if defined(PLATFORM_WEB)
    #include <emscripten/emscripten.h>
    #include <emscripten/fetch.h>
#endif

// C has no std::min / std::max, so here are two little macros that do the same job.
#define MINV(a, b) ((a) < (b) ? (a) : (b))
#define MAXV(a, b) ((a) > (b) ? (a) : (b))

// C has no std::vector either. Each list below is a plain array plus a counter
// (for example items[] and itemsCount). PUSH adds to the end of a list.
// FOREACH(Type, name, list) loops over a list: "name" is a copy of each element in turn.
#define FOREACH(T, v, list) for (int v##_i = 0, v##_go = 1; v##_i < list##Count; v##_i++, v##_go = 1) for (T v = list[v##_i]; v##_go; v##_go = 0)
#define PUSH(list, ...) do { if (list##Count < (int)(sizeof(list) / sizeof((list)[0]))) list[list##Count++] = __VA_ARGS__; } while (0)

// ---------------------------------------------------------------------
// 1. SETTINGS
// ---------------------------------------------------------------------
#define SCREEN_W (800)      // window size AND the numbers the game logic uses
#define SCREEN_H (600)
#define VW (400)            // the small pixel canvas we actually draw on
#define VH (300)
#define GROUND_Y (540.0f)   // y position of the floor (logic numbers)
#define GV (270)            // the same floor, on the small canvas

// Where in the world to get the weather for. Change these to your town!
// (Find coordinates by right-clicking a spot on Google Maps.)
#define LATITUDE (51.51)
#define LONGITUDE (-0.13)

// Convert a logic number (800x600) to a pixel on the small canvas (400x300).
static inline int V(float logic) { return (int)floorf(logic * 0.5f); }

// ---------------------------------------------------------------------
// 2. DATA TYPES
// ---------------------------------------------------------------------

// The three screens of the game.
typedef enum { STATE_TITLE, STATE_PLAYING, STATE_GAMEOVER } GameState;

// The kinds of weather the game understands.
typedef enum { W_CLEAR, W_CLOUDY, W_RAIN, W_SNOW, W_STORM, W_COUNT } WeatherType;

// The kinds of things that fall from the sky.
typedef enum { K_SOUL = 0, K_SKULL = 1, K_BAT = 2, K_POWER = 3 } ItemKind;

// The power-ups.
typedef enum { P_HEAL, P_SHIELD, P_MAGNET, P_WIDE, P_SLOW, P_COUNT } PowerType;

// The two difficulty modes.
typedef enum { MODE_NORMAL, MODE_HARD, MODE_COUNT } GameMode;

// One row of "rules" per weather type: colours AND gameplay numbers.
typedef struct WeatherRules {
    const char* name;
    const char* tip;           // hint shown on screen
    Color skyTop, skyBottom;   // background gradient
    Color ground;              // floor colour
    Color cloud;               // cloud colour
    float cloudAlpha;          // how visible clouds are (0-1)
    float fogAlpha;            // how thick the ground fog is (0-1)
    int   particles;           // how many rain/snow particles
    float accel;               // how strongly the player speeds up
    float friction;            // how quickly the player slows down (low = slippery)
    float fallSpeed;           // multiplier for falling object speed
    float hazardRate;          // multiplier for how often hazards appear
    int   coinPoints;          // base points per soul
    Color hazardColor;         // glow colour of hazards in this weather
} WeatherRules;

// This table IS the game design for weather. Tweak the numbers to change how it feels.
static const WeatherRules RULES[W_COUNT] = {
  // name           tip                                                 skyTop (high)       skyBottom (horizon) ground (grass)     cloud              cloudA fogA  parts accel fric  fall  haz  pts  hazardColor
  { "Clear Dusk",   "Clear dusk: the sky glows. Souls are worth double!",    {36,22,74,255},  {240,132,88,255},   {46,84,54,255},    {168,86,124,255},  0.55f, 0.08f,   0, 2400, 6.0f, 1.00f, 0.8f, 20, {255,90,120,255}  },
  { "Overcast",     "Overcast: the sky is heavy. Nothing special.",          {34,30,58,255},  {132,98,112,255},   {44,62,52,255},    {98,78,104,255},   0.95f, 0.14f,   0, 2400, 6.0f, 1.10f, 1.0f, 10, {255,110,90,255}  },
  { "Rain",         "Rain: the grave mud is slick. You slide!",              {20,24,48,255},  {88,98,134,255},    {34,66,64,255},    {62,70,100,255},   1.00f, 0.18f, 150, 1700, 4.0f, 1.25f, 1.1f, 10, {110,170,255,255}  },
  { "Snow",         "Snow: a deathly hush. You wade slowly, things drift.",  {58,62,100,255}, {176,164,196,255},  {150,164,184,255}, {152,152,180,255}, 0.85f, 0.22f, 110, 1500, 5.0f, 0.65f, 0.9f, 10, {150,215,255,255} },
  { "Storm",        "Storm: the dead are restless!",                         {14,10,34,255},  {100,54,96,255},    {34,58,54,255},    {52,40,78,255},    1.00f, 0.16f, 170, 2000, 5.0f, 1.55f, 1.5f, 10, {200,110,255,255}  },
};

// One row of rules per difficulty mode.
typedef struct ModeRules {
    const char* name;
    const char* desc;
    int   lives;           // flames you start with (and the most you can have)
    float hazardMul;       // more hazards
    float fallMul;         // faster falling
    float rampSeconds;     // how long until the night is at its hardest
    int   scoreMul;        // points multiplier for souls
    float powerMul;        // time between power-ups (bigger = rarer)
    float windMul;         // wind strength multiplier
    Color color;
} ModeRules;

static const ModeRules MODES[MODE_COUNT] = {
  { "NORMAL", "3 flames. A fair night in the graveyard.",                3, 1.0f, 1.00f, 60.0f, 1, 1.0f, 1.0f, { 160, 255, 200, 255 } },
  { "HARD",   "2 flames, faster dead, gale winds. Souls worth x2!",       2, 1.5f, 1.20f, 30.0f, 2, 1.5f, 2.0f, { 255,  90,  90, 255 } },
};

// Info for each power-up.
typedef struct PowerInfo {
    const char* name;
    Color       color;
    float       duration;   // seconds (0 = instant or until used)
} PowerInfo;

static const PowerInfo POWERS[P_COUNT] = {
  { "+1 FLAME",     { 255, 100,  90, 255 },  0.0f },
  { "WARD",         {  96, 160, 255, 255 },  0.0f },
  { "SOUL MAGNET",  { 196, 120, 255, 255 }, 10.0f },
  { "WIDE LIGHT",   { 255, 226, 110, 255 }, 10.0f },
  { "SLOW TIME",    { 170, 230, 255, 255 },  7.0f },
};

// Everything we learn from the weather request.
typedef struct WeatherData {
    WeatherType type;
    float       tempC;
    float       windKmh;
    float       windDir;      // degrees the wind comes FROM (270 = west wind)
    bool        live;         // true once real data has arrived
    char        status[80];
} WeatherData;

typedef struct Player {
    float x;
    float vx;               // horizontal velocity
    int   lives;            // flames left
    float invuln;           // seconds of "can't be hit" after a hit
    float bob;              // animation timer
    bool  shield;           // true while a Ward is protecting you
} Player;

// Anything that falls from the sky: a soul (good), a skull/bat (bad), or a power-up (good).
// Skulls and bats always glow a threatening red, whatever the weather.
#define HAZARD_GLOW ((Color){ 255, 50, 60, 255 })

typedef struct Item {
    Vector2 pos;            // logic position (800x600 numbers)
    float   radius;
    float   vy;             // fall speed
    float   spin;           // animation timer (flicker / wing flap / wobble)
    bool    hazard;
    Color   color;
    int     kind;           // K_SOUL, K_SKULL, K_BAT or K_POWER
    int     power;          // which power-up (only used when kind == K_POWER)
} Item;

// Little glowing dots that burst out when you catch something. (canvas coordinates)
typedef struct Spark { Vector2 pos, vel; float life; Color color; } Spark;

// Floating "+20" text. (canvas coordinates)
typedef struct Popup { Vector2 pos; float life; char text[24]; Color color; } Popup;

// Background decoration - all of these use small-canvas coordinates.
typedef struct Drop { float x, y, speed, size, phase; } Drop;   // rain drop / snowflake
typedef struct Cloud { float x, y, scale, speed; } Cloud;
typedef struct Fog { float x, y, w, speed; } Fog;
typedef struct Star { float x, y, size, phase; } Star;
typedef struct Tomb { int x, dy, type; } Tomb;                  // type 0 = round, 1 = cross, 2 = slab
typedef struct BgBat { float x, y, speed, phase; } BgBat;
typedef struct EyePair { int x, y; float offset; } EyePair;           // creepy eyes in the dark
typedef struct Grass { int x, y, h, shade; } Grass;

// A pixel-art picture stored as a GPU texture.
typedef struct Sprite { Texture2D tex; int w, h; } Sprite;

// ---------------------------------------------------------------------
// GLOBAL GAME STATE (one copy of each, used by all the functions below)
// ---------------------------------------------------------------------
static GameState gameState = STATE_TITLE;
static GameMode  mode = MODE_NORMAL;
static WeatherData weather = { W_CLEAR, 15.0f, 8.0f, 270.0f, false, "Summoning the weather..." };
static Player player = { SCREEN_W / 2.0f, 0, 3, 0, 0, false };
static Item items[512]; static int itemsCount = 0;
static Spark sparks[1500]; static int sparksCount = 0;
static Popup popups[64]; static int popupsCount = 0;
static Drop drops[200]; static int dropsCount = 0;
static Cloud clouds[8]; static int cloudsCount = 0;
static Fog fogs[12]; static int fogsCount = 0;
static Star stars[80]; static int starsCount = 0;
static Tomb tombs[40]; static int tombsCount = 0;
static BgBat bgBats[6]; static int bgBatsCount = 0;
static EyePair eyes[4]; static int eyesCount = 0;
static Grass grass[64]; static int grassCount = 0;      // pebbles in the dirt
static int  dripLen[400];                // how far the grass hangs over the dirt, per column
static Texture2D skyTex; static Color* skyPix = NULL; static unsigned skyKey = 0xFFFFFFFF;

static RenderTexture2D canvas;   // the small 400x300 pixel canvas

static int   score = 0, combo = 0;
static int   bestScore[MODE_COUNT] = { 0, 0 };
static bool  newBest = false;
static bool  paused = false;
static float playTime = 0;       // seconds survived this run
static float totalTime = 0;      // seconds since the program started (for animations)
static float hazardTimer = 0, coinTimer = 0, powerTimer = 0;
static float shake = 0;          // screen shake strength
static float hitFlash = 0;       // red flash when you get hurt
static float buff[P_COUNT] = { 0 };   // seconds left on timed power-ups

// Smoothly-blended visuals so the night fades between weather types
// instead of snapping. Colours are stored as Vector3 (r,g,b as floats).
static Vector3 vSkyTop    = {8,10,30};
static Vector3 vSkyBottom = {38,48,92};
static Vector3 vGround    = {26,40,36};
static Vector3 vCloud     = {70,76,110};
static float   vCloudAlpha = 0.30f;
static float   vMoonAlpha  = 1.0f;
static float   vFogAlpha   = 0.10f;
static float   vBlood      = 0.0f;   // 0 = normal moon, 1 = blood moon (hard mode)

// Lightning (only in storms)
static float lightningTimer = 2.0f;
static float flash = 0;
static Vector2 bolt[32]; static int boltCount = 0;    // canvas coordinates

// ---- GENERATED PIXEL ART (edit gen_sprites.py, not this block) ----
// Palette: each letter in a sprite maps to a colour below.
static Color PalColor(char c) {
    switch (c) {
        case 'o': return (Color){ 8, 6, 16, 255 };
        case 'a': return (Color){ 34, 26, 66, 255 };
        case 'b': return (Color){ 62, 50, 112, 255 };
        case 'c': return (Color){ 98, 84, 160, 255 };
        case 'f': return (Color){ 226, 218, 200, 255 };
        case 's': return (Color){ 172, 162, 148, 255 };
        case 'r': return (Color){ 225, 55, 65, 255 };
        case 'R': return (Color){ 140, 28, 40, 255 };
        case 'y': return (Color){ 255, 196, 80, 255 };
        case 'Y': return (Color){ 255, 242, 176, 255 };
        case 'O': return (Color){ 240, 128, 40, 255 };
        case 'w': return (Color){ 232, 226, 206, 255 };
        case 'x': return (Color){ 166, 158, 138, 255 };
        case 't': return (Color){ 126, 255, 228, 255 };
        case 'T': return (Color){ 60, 184, 172, 255 };
        case 'W': return (Color){ 255, 255, 255, 255 };
        case 'u': return (Color){ 46, 30, 60, 255 };
        case 'U': return (Color){ 92, 62, 116, 255 };
        case 'n': return (Color){ 104, 74, 48, 255 };
        case 'N': return (Color){ 62, 42, 30, 255 };
        case 'g': return (Color){ 92, 106, 140, 255 };
        case 'h': return (Color){ 140, 156, 192, 255 };
        case 'H': return (Color){ 60, 70, 104, 255 };
        case 'm': return (Color){ 70, 120, 84, 255 };
        case 'B': return (Color){ 96, 160, 255, 255 };
        case 'D': return (Color){ 44, 88, 176, 255 };
        case 'P': return (Color){ 196, 120, 255, 255 };
        case 'p': return (Color){ 112, 64, 172, 255 };
        case 'L': return (Color){ 255, 236, 120, 255 };
        case 'I': return (Color){ 170, 230, 255, 255 };
        case 'i': return (Color){ 90, 160, 200, 255 };
        case 'G': return (Color){ 60, 130, 70, 255 };
        case 'E': return (Color){ 255, 196, 64, 255 };
        case 'J': return (Color){ 22, 16, 38, 255 };
        case 'j': return (Color){ 84, 82, 98, 255 };
        case 'k': return (Color){ 6, 4, 12, 255 };
        case 'M': return (Color){ 236, 64, 176, 255 };
        case 'q': return (Color){ 140, 28, 108, 255 };
        case 'V': return (Color){ 214, 150, 255, 255 };
        case 'F': return (Color){ 64, 214, 206, 255 };
        case 'z': return (Color){ 22, 104, 140, 255 };
        case 'e': return (Color){ 50, 56, 88, 255 };
        case 'S': return (Color){ 190, 200, 224, 255 };
        default:  return (Color){ 0, 0, 0, 0 };   // '.' = transparent
    }
}

static const char* const SPR_PLAYER_A[] = {
    "..................",
    ".......oooo.......",
    "......ocbabo......",
    ".....occbabbo.....",
    ".....occbabbo.....",
    "....occbbaabbo....",
    "....occbkkabbo....",
    "...occbkkkkabbo...",
    "...ocbkkkkkkabo...",
    "..ocbkkkkkkkkabo..",
    "..ocbkEkkkkEkabo..",
    "..ocbkEkkkkEkabo..",
    "..ocbkkkkkkkkabo..",
    "..ocbbkkkkkkaabo..",
    "...ocbbbkkaaabo...",
    "...ocbbbbaaaabo...",
    ".occbbbbaaaaaabbo.",
    ".occbbbbaaaaaabbo.",
    ".ocbabbbaaaaaaabo.",
    ".ocbabbbaaaaaaabo.",
    ".ocbabbbaaaaaaabo.",
    ".ocbabbbaaaaaaabo.",
    ".ocbbbbbaaaaaaabo.",
    "ooJJJJJJEEJJJJJJoo",
    "ooJJJJJJEEJJJJJJoo",
    "occbbbbbaaaaaaabbo",
    "occbabbbaaaaaaabbo",
    "occbabbbaaaaaaabbo",
    "occbbbbbaaaaaaabbo",
    "oocbbbbbaaaaaaaboo",
    "oooooooooooooooooo",
    "...ojjjjoojjjjo...",
    "...ooooo..ooooo...",
};
static const char* const SPR_PLAYER_B[] = {
    "..................",
    ".......oooo.......",
    "......ocbabo......",
    ".....occbabbo.....",
    ".....occbabbo.....",
    "....occbbaabbo....",
    "....occbkkabbo....",
    "...occbkkkkabbo...",
    "...ocbkkkkkkabo...",
    "..ocbkkkkkkkkabo..",
    "..ocbkEkkkkEkabo..",
    "..ocbkEkkkkEkabo..",
    "..ocbkkkkkkkkabo..",
    "..ocbbkkkkkkaabo..",
    "...ocbbbkkaaabo...",
    "...ocbbbbaaaabo...",
    ".occbbbbaaaaaabbo.",
    ".occbbbbaaaaaabbo.",
    ".ocbabbbaaaaaaabo.",
    ".ocbabbbaaaaaaabo.",
    ".ocbabbbaaaaaaabo.",
    ".ocbabbbaaaaaaabo.",
    ".ocbbbbbaaaaaaabo.",
    "ooJJJJJJEEJJJJJJoo",
    "ooJJJJJJEEJJJJJJoo",
    "occbbbbbaaaaaaabbo",
    "occbabbbaaaaaaabbo",
    "occbabbbaaaaaaabbo",
    "occbbbbbaaaaaaabbo",
    "oocbbbbbaaaaaaaboo",
    "oooooooooooooooooo",
    "..ojjjjo..ojjjjo..",
    "..ooooo....ooooo..",
};
static const char* const SPR_LANTERN_A[] = {
    "...o...",
    "..ooo..",
    ".ooooo.",
    "oyYYYyo",
    "oyYYYyo",
    "oyYWYyo",
    "oyYYYyo",
    "oyyYyyo",
    ".ooooo.",
    "..ooo..",
};
static const char* const SPR_LANTERN_B[] = {
    "...o...",
    "..ooo..",
    ".ooooo.",
    "oyyYyyo",
    "oyYYYyo",
    "oyYWYyo",
    "oyYWYyo",
    "oyYYYyo",
    ".ooooo.",
    "..ooo..",
};
static const char* const SPR_SOUL_A[] = {
    ".....z.....",
    ".....F.....",
    "....zFz....",
    "...zFFFz...",
    "..zFtttFz..",
    ".zFtttttFz.",
    ".zFtWWWtFz.",
    "zFtWWWWWtFz",
    "zFkWWWWWkFz",
    "zFkWWWWWkFz",
    "zFtkWWWktFz",
    ".zFtkkktFz.",
    ".zFFtttFFz.",
    "..zFFtFFz..",
    "...zzFzz...",
    "....zzz....",
};
static const char* const SPR_SOUL_B[] = {
    "....z.z....",
    "....FFF....",
    "...zFFFz...",
    "...zFFFz...",
    "..zFtttFz..",
    ".zFtttttFz.",
    ".zFtWWWtFz.",
    "zFtWWWWWtFz",
    "zFkWWWWWkFz",
    "zFkWWWWWkFz",
    "zFtkWWWktFz",
    ".zFtkkktFz.",
    ".zFFtttFFz.",
    "..zFFtFFz..",
    "...zzFzz...",
    "....zzz....",
};
static const char* const SPR_SKULL[] = {
    "...ooooooo...",
    "..owwwwwwwo..",
    ".owwwwwwwwwo.",
    ".owwwwwwwwwo.",
    ".owwwwwwwwwo.",
    ".okkkwwwkkko.",
    ".okrkwwwkrko.",
    ".okkkwwwkkko.",
    ".owwwwwwwwwo.",
    "..owwwkwwwo..",
    "..oxwwwwwxo..",
    "...owxwxwo...",
    "...owkwkwo...",
    "....ooooo....",
};
static const char* const SPR_FLAME_HAZ_A[] = {
    ".........q.........",
    "........qMq........",
    "........MMM........",
    ".......qMMMq.......",
    "...q..qMVVVMq..q...",
    "...qM.qMVVVMq.Mq...",
    "..qMMqMMVVVMMqMMq..",
    "..qMMMMVVVVVMMMMq..",
    ".qMMMVVVVVVVVVMMMq.",
    ".qMMVVVVVVVVVVVMMq.",
    "qMMVVVVVVVVVVVVVMMq",
    "qMMVVVVVVVVVVVVVMMq",
    "qMMVVVVVVVVVVVVVMMq",
    "qMMVVVVVVVVVVVVVMMq",
    "qMMMVVVVVVVVVVVMMMq",
    ".qMMMVVVVVVVVVMMMq.",
    ".qqMMMMVVVVVMMMMqq.",
    "..qqqMMMMMMMMMqqq..",
    "....qqqqqqqqqqq....",
};
static const char* const SPR_FLAME_HAZ_B[] = {
    "........q.q........",
    ".......qM.Mq.......",
    "..q....MM.MM....q..",
    "..qM..qMMVMMq..Mq..",
    "..qMq.qMVVVMq.qMq..",
    "...qM.qMVVVMq.Mq...",
    "..qMMqMMVVVMMqMMq..",
    "..qMMMMVVVVVMMMMq..",
    ".qMMMVVVVVVVVVMMMq.",
    ".qMMVVVVVVVVVVVMMq.",
    "qMMVVVVVVVVVVVVVMMq",
    "qMMVVVVVVVVVVVVVMMq",
    "qMMVVVVVVVVVVVVVMMq",
    "qMMVVVVVVVVVVVVVMMq",
    "qMMMVVVVVVVVVVVMMMq",
    ".qMMMVVVVVVVVVMMMq.",
    ".qqMMMMVVVVVMMMMqq.",
    "..qqqMMMMMMMMMqqq..",
    "....qqqqqqqqqqq....",
};
static const char* const SPR_BAT_A[] = {
    "uu......o.o......uu",
    "uUu.....uou.....uUu",
    "uUUu...ouuuo...uUUu",
    "uUUUu.oururuo.uUUUu",
    ".uUUUuuuuuuuuuUUUu.",
    "..uUUuuuuuuuuuUUu..",
    "...uuuuuuuuuuuuu...",
    ".....uuuuuuuuu.....",
    "......uuuuuuu......",
    ".......uuuuu.......",
    "........uuu........",
};
static const char* const SPR_BAT_B[] = {
    "........o.o........",
    ".......uuouu.......",
    "......ouuuuuo......",
    "......oururuo......",
    "..uu.uuuuuuuuu.uu..",
    ".uUUuuuuuuuuuuuUUu.",
    "uUUUUuuuuuuuuuUUUUu",
    "uUUUuuuuuuuuuuuUUUu",
    "uUu..uuuuuuuuu..uUu",
    "uu....uuuuuuu....uu",
    ".......uuuuu.......",
};
static const char* const SPR_ICON_HEAL[] = {
    ".ooo...ooo.",
    "orWrrrrrWro",
    "orrrrrrrrro",
    "orrrrrrrrro",
    ".orrrrrrro.",
    "..orrrrro..",
    "...orrro...",
    "....oro....",
    ".....o.....",
};
static const char* const SPR_ICON_SHIELD[] = {
    "ooooooooooo",
    "oBBBBBBBBBo",
    "oBWBBBBBWBo",
    "oBBBBDBBBBo",
    "oBBBBDBBBBo",
    "oBBBBDBBBBo",
    ".oBBBDBBBo.",
    ".oBBBDBBBo.",
    "..oBBDBBo..",
    "...oBDBo...",
    "....ooo....",
    ".....o.....",
};
static const char* const SPR_ICON_MAGNET[] = {
    "ooo.....ooo",
    "ohho...ohho",
    "ohho...ohho",
    "oPPo...oPPo",
    "oPPo...oPPo",
    "oPPo...oPPo",
    "oPPPoooPPPo",
    "oPPPPPPPPPo",
    ".oPPPPPPPo.",
    "..ooooooo..",
};
static const char* const SPR_ICON_WIDE[] = {
    ".....L.....",
    ".L.......L.",
    "...ooooo...",
    "..oyyyyyo..",
    ".oyYYYYYyo.",
    "LoyYYYYYyoL",
    ".oyYYYYYyo.",
    "..oyyyyyo..",
    "...ooooo...",
    ".L.......L.",
    ".....L.....",
};
static const char* const SPR_ICON_SLOW[] = {
    "ooooooooooo",
    "oIIIIIIIIIo",
    ".oIIIIIIIo.",
    "..oIIIIIo..",
    "...oIIIo...",
    "....oIo....",
    "...oIIIo...",
    "..oIIIIIo..",
    ".oIIIIIIIo.",
    "oIIIIIIIIIo",
    "ooooooooooo",
};
static const char* const SPR_TOMB_ROUND[] = {
    "......oooooooo......",
    "....oohhhhggggoo....",
    "...ohhhhhhggggggo...",
    "...ohSShhgHgghhgo...",
    "..ohSShhggHHgghhgo..",
    "..ohhhhgggHHHggggo..",
    "..ohhgggggHHHHHggo..",
    "..ohhgggggHHHHHggo..",
    "..ohhgggeeeeHHHggo..",
    "..ohhgggeeeeHHHggo..",
    "..ohhgeeeeeeeeHggo..",
    "..ohhgggeeeeHHHggo..",
    "..ohhgggeeeeHHHggo..",
    "..ohhgggeeeeHHHggo..",
    "..ohhgggggHHHHHggo..",
    "..ohhgmgggHHHmHggo..",
    "..ohgmmgggHHHmmHgo..",
    "..ohggggggHHHHHHgo..",
    "..ohggggggHHHHHHgo..",
    ".ooohhhhhhggggggooo.",
    ".ohhhgggggHHHHHgggo.",
    ".ohhgggggeeHHHHHggo.",
    ".oHHHHHHHHHHHHHHHHo.",
    ".oooooooooooooooooo.",
};
static const char* const SPR_TOMB_CROSS[] = {
    ".......oooooo.......",
    "......ohhhgggo......",
    "......ohhgHggo......",
    "......ohhgHggo......",
    "oooooooohhggoooooooo",
    "ohhhhhhhhhgggggggggo",
    "ohhhhhhgggHHHggggggo",
    "ooooooohggHHgooooooo",
    ".......ohgHgo.......",
    ".......ohgHgo.......",
    ".......ohgHgo.......",
    ".......ohgHgo.......",
    ".......ohgHgo.......",
    ".......ohgHgo.......",
    ".......ohgHgo.......",
    ".......ohgHgo.......",
    ".......ohgHgo.......",
    "...oooooooooooooo...",
    "..ohhhhhhhgggggggo..",
    "..ohhgggggHHHHHggo..",
    "..ohggggggHHHHHHgo..",
    "..oHHHHHHHHHHHHHHo..",
    "..oooooooooooooooo..",
};
static const char* const SPR_TOMB_SLAB[] = {
    ".....oooooooooo.....",
    "...ooohhhhggggooo...",
    "..ohhhhhhhgggggggo..",
    ".ohhShhhhhggggghggo.",
    ".ohSShhhggHHggghhgo.",
    ".ohhhhhgggHHHgggggo.",
    ".ohheeegggHHHeeeggo.",
    ".ohhe.egggHHHe.eggo.",
    ".ohheeegggHHHeeeggo.",
    ".ohhe.eggeeHHe.eggo.",
    ".ohhe.egggHHHe.eggo.",
    ".ohhhhhgggHHHgggggo.",
    ".ohhhhgggeeHHHggggo.",
    ".ohhgggggeeHHHHHggo.",
    ".ohhggggggHHHHHHggo.",
    ".ohhgmggggHHHHmHggo.",
    ".ohggmmgggHHHmmHHgo.",
    ".ohggggggeeHHHHHHgo.",
    "ooHHHHHHHHHHHHHHHHoo",
    "oooooooooooooooooooo",
};
static const char* const SPR_PUMPKIN[] = {
    ".....N.....",
    "..ooOOOoo..",
    ".oOOOOOOOo.",
    "oOOYOOOYOOo",
    "oOOOOOOOOOo",
    "oOYOYYYOYOo",
    ".oOOOOOOOo.",
    "..ooOOOoo..",
    "....ooo....",
};
static const char* const SPR_FLAME[] = {
    "....o....",
    "...oyo...",
    "..oyyyo..",
    ".oyYYYyo.",
    ".oyYYYyo.",
    ".oyYYYyo.",
    "..oyyyo..",
    "...ooo...",
};


// The actual sprites, created once at startup from the text pictures above.
static Sprite sprPlayerA, sprPlayerB, sprLanternA, sprLanternB, sprSoulA, sprSoulB, sprSkull,
              sprBatA, sprBatB, sprHeal, sprShield, sprMagnet, sprWide, sprSlow,
              sprTombRound, sprTombCross, sprTombSlab, sprPumpkin, sprFlame, sprHazA, sprHazB;

// Turn a text picture into a texture. Each letter = one pixel (see PalColor).
static Sprite MakeSprite(const char* const* rows, int h) {
    int w = (int)strlen(rows[0]);
    Image img = GenImageColor(w, h, BLANK);
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w && rows[y][x]; x++)
            ImageDrawPixel(&img, x, y, PalColor(rows[y][x]));
    Sprite s;
    s.tex = LoadTextureFromImage(img);
    s.w = w; s.h = h;
    UnloadImage(img);
    return s;
}
#define MAKE(arr) MakeSprite(arr, (int)(sizeof(arr) / sizeof((arr)[0])))

static void LoadSprites(void) {
    sprPlayerA = MAKE(SPR_PLAYER_A);   sprPlayerB = MAKE(SPR_PLAYER_B);
    sprLanternA = MAKE(SPR_LANTERN_A); sprLanternB = MAKE(SPR_LANTERN_B);
    sprSoulA = MAKE(SPR_SOUL_A);       sprSoulB = MAKE(SPR_SOUL_B);
    sprSkull = MAKE(SPR_SKULL);
    sprBatA = MAKE(SPR_BAT_A);         sprBatB = MAKE(SPR_BAT_B);
    sprHeal = MAKE(SPR_ICON_HEAL);     sprShield = MAKE(SPR_ICON_SHIELD);
    sprMagnet = MAKE(SPR_ICON_MAGNET); sprWide = MAKE(SPR_ICON_WIDE);
    sprSlow = MAKE(SPR_ICON_SLOW);
    sprTombRound = MAKE(SPR_TOMB_ROUND); sprTombCross = MAKE(SPR_TOMB_CROSS);
    sprTombSlab = MAKE(SPR_TOMB_SLAB);
    sprPumpkin = MAKE(SPR_PUMPKIN);    sprFlame = MAKE(SPR_FLAME);
    sprHazA = MAKE(SPR_FLAME_HAZ_A);   sprHazB = MAKE(SPR_FLAME_HAZ_B);
}

static Sprite PowerSprite(int p) {
    switch (p) {
        case P_HEAL:   return sprHeal;
        case P_SHIELD: return sprShield;
        case P_MAGNET: return sprMagnet;
        case P_WIDE:   return sprWide;
        default:       return sprSlow;
    }
}

// ---------------------------------------------------------------------
// SMALL HELPER FUNCTIONS
// ---------------------------------------------------------------------
static float RandF(float a, float b) { return a + (b - a) * ((float)rand() / (float)RAND_MAX); }

static float Clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

// Move colour 'a' a little bit toward colour 'b'. k = how fast (0-1).
static Vector3 Approach(Vector3 a, Color b, float k) {
    return (Vector3){ a.x + (b.r - a.x) * k, a.y + (b.g - a.y) * k, a.z + (b.b - a.z) * k };
}

static Color ToColor(Vector3 v, float scale, unsigned char a) {
    return (Color){ (unsigned char)Clampf(v.x * scale, 0, 255), (unsigned char)Clampf(v.y * scale, 0, 255),
             (unsigned char)Clampf(v.z * scale, 0, 255), a };
}

static Vector3 Lerp3(Vector3 a, Vector3 b, float t) {
    return (Vector3){ a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t };
}

// Hard mode pushes the whole night toward red.
static Color HardTint(Color c) {
    c.r = (unsigned char)MINV(255, (int)c.r + 30);
    c.g = (unsigned char)(c.g * 0.85f);
    c.b = (unsigned char)(c.b * 0.85f);
    return c;
}

// Draw a sprite with its top-left corner at (x, y). 'flip' mirrors it left-right.
static void DrawSpr(Sprite s, int x, int y, bool flip, Color tint) {
    Rectangle src = { 0, 0, (float)(flip ? -s.w : s.w), (float)s.h };
    DrawTextureRec(s.tex, src, (Vector2){ (float)x, (float)y }, tint);
}

// Draw a sprite centred on (cx, cy).
static void DrawSprC(Sprite s, int cx, int cy, bool flip, Color tint) {
    DrawSpr(s, cx - s.w / 2, cy - s.h / 2, flip, tint);
}

// A chunky pixel line: a line of t x t squares (Bresenham's algorithm).
static void PixLine(int x0, int y0, int x1, int y1, int t, Color c) {
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;
    for (;;) {
        DrawRectangle(x0 - t / 2, y0 - t / 2, t, t, c);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
}

// A glow made of a few stepped see-through circles (stepped = pixel-art look).
// Drawn with ADDITIVE blending so it brightens what's behind it.
static void DrawGlow(int cx, int cy, int radius, Color col, float strength) {
    BeginBlendMode(BLEND_ADDITIVE);
    for (int i = 4; i >= 1; i--)
        DrawCircle(cx, cy, (float)(radius * i / 4), Fade(col, (col.a / 255.0f) * 0.10f * strength));
    EndBlendMode();
}

// Text with a 1-pixel drop shadow - keeps it readable on any background.
static void DrawTextShadow(const char* text, int x, int y, int size, Color c) {
    DrawText(text, x + 1, y + 1, size, Fade(BLACK, 0.8f));
    DrawText(text, x, y, size, c);
}

static void DrawTextCenteredShadow(const char* text, int cx, int y, int size, Color c) {
    DrawTextShadow(text, cx - MeasureText(text, size) / 2, y, size, c);
}

// Dark edges of the screen, in stepped rings. Makes everything feel like you're
// peering out of the dark. 'tint' lets us pulse red when you're nearly dead.
static void DrawVignette(float strength, Color tint) {
    for (int i = 0; i < 6; i++) {
        int in = i * 10;
        float a = strength * powf(1.0f - i / 6.0f, 1.6f) * 0.5f;
        Color c = Fade(tint, a);
        DrawRectangle(in, in, VW - 2 * in, 10, c);
        DrawRectangle(in, VH - in - 10, VW - 2 * in, 10, c);
        DrawRectangle(in, in + 10, 10, VH - 2 * in - 20, c);
        DrawRectangle(VW - in - 10, in + 10, 10, VH - 2 * in - 20, c);
    }
}

// ---------------------------------------------------------------------
// 4. THE WEB REQUEST
// ---------------------------------------------------------------------
// We call Open-Meteo (https://open-meteo.com) - a free weather API that
// needs NO account or key. The reply is JSON text that looks like:
//
//   {"current":{"time":"...","temperature_2m":12.3,"weather_code":61,
//               "wind_speed_10m":14.2,"wind_direction_10m":240}}
//
// "weather_code" is a standard WMO number (0 = clear, 61 = rain, 95 = storm...)

// Convert a WMO weather code number into one of our 5 weather types.
static WeatherType CodeToWeather(int c) {
    if (c <= 1)  return W_CLEAR;                              // 0,1 clear
    if (c <= 48) return W_CLOUDY;                             // 2,3 cloud, 45,48 fog
    if ((c >= 71 && c <= 77) || c == 85 || c == 86) return W_SNOW;
    if (c >= 95) return W_STORM;                              // thunderstorms
    return W_RAIN;                                            // drizzle, rain, showers
}

// Find a number after a key name inside the JSON text, e.g. "weather_code":61
// We only look AFTER the word "current" so we read the live values.
static bool FindNumber(const char* json, const char* key, float* out) {
    const char* start = strstr(json, "\"current\":{");
    if (!start) return false;
    char needle[64];
    snprintf(needle, sizeof(needle), "\"%s\":", key);
    const char* p = strstr(start, needle);
    if (!p) return false;
    *out = (float)atof(p + strlen(needle));
    return true;
}

// Read the JSON reply and store the results in the 'weather' variable.
static void ParseWeather(const char* json) {
    float code, temp, wind, dir;
    if (!FindNumber(json, "weather_code", &code)) {
        snprintf(weather.status, sizeof(weather.status), "%s", "Weather reply unreadable - using default");
        return;
    }
    weather.type = CodeToWeather((int)code);
    if (FindNumber(json, "temperature_2m", &temp))      weather.tempC = temp;
    if (FindNumber(json, "wind_speed_10m", &wind))      weather.windKmh = wind;
    if (FindNumber(json, "wind_direction_10m", &dir))   weather.windDir = dir;
    weather.live = true;
    snprintf(weather.status, sizeof(weather.status), "%s", "LIVE weather");
}

#if defined(PLATFORM_WEB)
// Called by the browser if the request worked.
static void OnFetchSuccess(emscripten_fetch_t* fetch) {
    char* body = (char*)malloc((size_t)fetch->numBytes + 1);     // copy the reply and add the '\0' that ends a C string
    memcpy(body, fetch->data, (size_t)fetch->numBytes);
    body[fetch->numBytes] = 0;
    ParseWeather(body);
    free(body);
    emscripten_fetch_close(fetch);   // always free the request when done
}

// Called by the browser if the request failed (no internet, blocked, etc).
// The game still works - it just keeps the default weather.
static void OnFetchFail(emscripten_fetch_t* fetch) {
    snprintf(weather.status, sizeof(weather.status), "%s", "Offline - using default (press 1-5 to preview)");
    emscripten_fetch_close(fetch);
}
#endif

// Start the request. It runs in the background - the game keeps running
// and the weather simply updates when the reply arrives.
static void FetchWeather(void) {
#if defined(PLATFORM_WEB)
    char url[400];
    snprintf(url, sizeof(url),
        "https://api.open-meteo.com/v1/forecast?latitude=%.2f&longitude=%.2f"
        "&current=temperature_2m,weather_code,wind_speed_10m,wind_direction_10m",
        LATITUDE, LONGITUDE);

    snprintf(weather.status, sizeof(weather.status), "%s", "Summoning the weather...");
    emscripten_fetch_attr_t attr;
    emscripten_fetch_attr_init(&attr);
    snprintf(attr.requestMethod, sizeof(attr.requestMethod), "GET");
    attr.attributes = EMSCRIPTEN_FETCH_LOAD_TO_MEMORY;
    attr.onsuccess = OnFetchSuccess;
    attr.onerror   = OnFetchFail;
    emscripten_fetch(&attr, url);
#else
    // Desktop build has no web request - use the 1-5 keys to pick weather.
    snprintf(weather.status, sizeof(weather.status), "%s", "Desktop build - press 1-5 to preview weather");
#endif
}

// Pretend the weather is a certain type (keys 1-5). Great for testing
// and for recording your GIF without waiting for real rain.
static void PreviewWeather(WeatherType t) {
    weather.type = t;
    weather.live = false;
    snprintf(weather.status, sizeof(weather.status), "%s", "PREVIEW weather");
    weather.windDir = 270.0f;
    static const float previewWind[W_COUNT] = { 6, 12, 14, 8, 32 };
    static const float previewTemp[W_COUNT] = { 9, 11, 8, -2, 10 };
    weather.windKmh = previewWind[t];
    weather.tempC = previewTemp[t];
}

// The wind as a sideways push. Wind "from the west" (270 deg) blows
// toward the east = +x on screen. Capped so it never gets unfair,
// and Hard mode makes it stronger.
static float WindPush(void) {
    float rad = weather.windDir * DEG2RAD;
    return -sinf(rad) * Clampf(weather.windKmh, 0, 35) * MODES[mode].windMul;
}

// ---------------------------------------------------------------------
// AUDIO - every sound is made by code, so there are no sound files to load.
//   * Music: a slow 8-bit funeral march (square-wave tune, triangle bass,
//     soft drums, echo). The notes are the MELODY[] table further down.
//   * Weather: a background soundscape that follows weather.type, so it
//     changes with the live weather AND with the 1-5 preview keys.
//   * Sound effects: made once at start-up into little Sounds.
// Audio is streamed in small chunks: FillMusic()/FillAmbient() write the
// next chunk of samples and UpdateAudio() hands them to raylib every frame.
// ---------------------------------------------------------------------
#define SR (22050)            // samples per second
#define AUDIO_HALF (2048)     // samples per refill (raylib's buffer holds two of these)
#define TAU (6.2831853f)

static bool  audioOK = false;           // false if the browser/computer gave us no sound device
static bool  muted = false;             // N: everything off
static bool  musicMuted = false;        // M: just the music off
static float thunderTimer = -1;         // counts down after a lightning flash, then rolls the thunder
static float beatTimer = 0;             // low-health heartbeat

static uint32_t rngState = 2463534242u;
static inline float Noise(void) {           // white noise, -1..1
    rngState ^= rngState << 13; rngState ^= rngState >> 17; rngState ^= rngState << 5;
    return (rngState & 0xFFFFFF) / 8388608.0f - 1.0f;
}
#define Slew(v, target, k) ((v) += ((target) - (v)) * (k))
static inline float Soft(float x) { return tanhf(x); }

// ---------------- Weather soundscape ----------------
typedef struct Ambience {
    float rain, wind, hush, cricket;   // current loudness of each layer (they fade toward targets)
    float rl, p1, w1, w2, hz1;      // filter memory
    float r1, r2, r3, r4, r5;       // rain filter memory
    float g1, g2, whistle, c1, c2, cenv1, cenv2;
    double t;
} Ambience;
static Ambience amb;
static bool rainFromFile = false;       // true = the rain comes from rain.wav instead of being built in code

static void FillAmbient(short* out, int n) {
    float tRain = 0, tWind = 0.2f, tHush = 0, tCrick = 0;
    float wk = Clampf(weather.windKmh / 45.0f, 0.0f, 1.0f);   // real wind speed -> louder wind
    switch (weather.type) {
        case W_CLEAR:  tWind = 0.15f + 0.5f * wk; tCrick = 0.9f; break;
        case W_CLOUDY: tWind = 0.30f + 0.6f * wk; tCrick = 0.25f; break;
        case W_RAIN:   tWind = 0.15f + 0.5f * wk; tRain = 0.75f; break;
        case W_SNOW:   tWind = 0.10f + 0.4f * wk; tHush = 0.9f; break;
        case W_STORM:  tWind = 0.45f + 0.8f * wk; tRain = 1.0f; break;
        default: break;
    }
    for (int i = 0; i < n; i++) {
        Slew(amb.rain, tRain, 0.00004f); Slew(amb.wind, tWind, 0.00004f);
        Slew(amb.hush, tHush, 0.00004f); Slew(amb.cricket, tCrick, 0.00004f);
        amb.t += 1.0 / SR;
        float nz = Noise();

        // Rain: a steady, dense "shhhh" made of thousands of tiny drops (band-passed noise),
        // a soft low patter underneath, and a few small, soft drop-plinks. A very slow swell
        // keeps it alive. (No sharp clicks - those sounded choppy.)
        float rn = Noise();
        amb.r1 += (rn - amb.r1) * 0.45f;                 // soften the very top
        amb.r2 += (amb.r1 - amb.r2) * 0.02f;             // slow part, subtracted -> removes the rumble
        float sh = amb.r1 - amb.r2;                      // band-passed hiss
        amb.r3 += (rn - amb.r3) * 0.10f;                 // low patter on leaves and graves
        amb.r4 += (amb.r3 - amb.r4) * 0.01f;
        float patter = amb.r3 - amb.r4;
        float plink = (Noise() > 0.9985f) ? Noise() : 0.0f;
        amb.r5 += (plink - amb.r5) * 0.25f;
        float swell = 1.0f + 0.10f * sinf((float)amb.t * 0.37f) + 0.05f * sinf((float)amb.t * 1.3f);
        float rain = (sh * 0.34f + patter * 0.30f + amb.r5 * 0.12f) * swell * amb.rain;
        if (rainFromFile) rain = 0.0f;                   // rain.wav plays instead (see UpdateAudio)

        // Wind: twice-filtered noise that swells and fades like gusts, plus a thin howl.
        amb.w1 += (nz - amb.w1) * 0.03f;
        amb.w2 += (amb.w1 - amb.w2) * 0.03f;
        amb.g1 += TAU * 0.11f / SR; amb.g2 += TAU * 0.37f / SR;
        float gust = 0.55f + 0.30f * sinf(amb.g1) + 0.15f * sinf(amb.g2 + 1.0f);
        float wind = amb.w2 * 3.2f * gust * amb.wind;
        amb.whistle += TAU * (330.0f + 160.0f * gust) / SR;
        wind += sinf(amb.whistle) * 0.020f * gust * gust * gust * amb.wind;

        // Snow: a soft, steady, muffled hush.
        amb.hz1 += (nz - amb.hz1) * 0.035f;
        float hush = amb.hz1 * 0.65f * amb.hush;

        // Crickets: two chirpers with different pitch and rhythm.
        float gate1 = (fmodf((float)amb.t * 0.55f, 1.0f) < 0.40f && fmodf((float)amb.t * 38.0f, 1.0f) < 0.55f) ? 1.0f : 0.0f;
        float gate2 = (fmodf((float)amb.t * 0.43f + 0.3f, 1.0f) < 0.35f && fmodf((float)amb.t * 31.0f, 1.0f) < 0.5f) ? 1.0f : 0.0f;
        Slew(amb.cenv1, gate1, 0.03f); Slew(amb.cenv2, gate2, 0.03f);
        amb.c1 += TAU * 4300.0f / SR; amb.c2 += TAU * 3650.0f / SR;
        float crick = (sinf(amb.c1) * amb.cenv1 + sinf(amb.c2) * amb.cenv2) * 0.035f * amb.cricket;

        float v = Soft((rain + wind + hush + crick) * 0.9f);
        out[i] = (short)(v * 30000.0f);
    }
}

// ---------------- 8-bit funeral march ----------------
// A slow, sad chiptune dirge in D minor, built from the same kinds of sounds as an old 8-bit console:
//   * lead   - a thin square wave (25% pulse) playing the melody
//   * arp    - a very quiet, even thinner pulse (12.5%) tinkling through each chord
//   * bass   - a triangle wave on beats 1 and 3
//   * drums  - a soft thumping kick on 1 and 3, and a short noise tick on 3
// The notes are written out as plain numbers in MELODY[] below (MIDI note numbers: 74 = D5), so you
// can change the tune. The whole thing is played once into a buffer at start-up (adding a crunchy
// "8-bit" sound by rounding the samples, plus echo and a touch of reverb), and then looped.
static float* musicLoop = NULL;      // the finished loop (a plain array of samples)
static int    musicLoopN = 0;

#define MUSIC_BPM (66.0f)                // slow, like a march at a funeral
#define MUSIC_BARS (8)                   // 8 bars of 8 eighth-note steps
static const int   MELODY[MUSIC_BARS][8] = {         // -1 = hold the previous note / rest
    { 74, -1, -1, 77, -1, 76, -1, -1 },  { 74, -1, -1, 73, -1, 69, -1, -1 },
    { 70, -1, -1, 74, -1, 72, -1, -1 },  { 69, -1, -1, -1, -1, -1, -1, -1 },
    { 74, -1, 77, -1, 81, -1, 79, -1 },  { 77, -1, 76, -1, 74, -1, 73, -1 },
    { 70, -1, 72, -1, 74, -1, 76, -1 },  { 74, -1, -1, -1, 69, -1, -1, -1 },
};
static const int BASS_ROOT[MUSIC_BARS] = { 38, 38, 34, 33, 38, 43, 34, 33 };      // D D Bb A D G Bb A
static const int CHORD_MINOR[MUSIC_BARS] = { 1, 1, 0, 0, 1, 1, 0, 0 };           // 1 = minor chord, 0 = major

static inline float Midi(int m) { return 440.0f * powf(2.0f, (m - 69) / 12.0f); }
static inline float Frac(float x) { return x - floorf(x); }

// Adds one note to the buffer. shape: 0 = square 25%, 1 = triangle, 2 = square 12.5%
static void AddNote(float* buf, int N, float start, float dur, float f, int shape, float amp, float decay) {
    int n = (int)(dur * SR), i0 = (int)(start * SR), rel = (int)(0.03f * SR);
    for (int j = 0; j < n; j++) {
        float t = j / (float)SR, ph = Frac(f * t), w;
        if (shape == 0) w = ph < 0.25f ? 1.0f : -1.0f;
        else if (shape == 2) w = ph < 0.125f ? 1.0f : -1.0f;
        else w = 2.0f * fabsf(2.0f * ph - 1.0f) - 1.0f;
        float env = fminf(1.0f, t / 0.004f) * expf(-t * decay);
        if (n > rel && j >= n - rel) env *= (n - j) / (float)rel;
        buf[(i0 + j) % N] += w * env * amp;
    }
}
static void AddKick(float* buf, int N, float start, float amp) {
    int n = (int)(0.3f * SR), i0 = (int)(start * SR); float ph = 0;
    for (int j = 0; j < n; j++) {
        float t = j / (float)SR;
        ph += (45.0f + 110.0f * expf(-t * 28.0f)) / SR;
        buf[(i0 + j) % N] += sinf(TAU * ph) * expf(-t * 12.0f) * amp;
    }
}
static void AddTick(float* buf, int N, float start, float dur, float amp, float decay) {
    int n = (int)(dur * SR), i0 = (int)(start * SR); float a = 0, b = 0;
    for (int j = 0; j < n; j++) {
        float t = j / (float)SR, x = Noise();
        float sm = (x + a + b) / 3.0f; b = a; a = x;                // softened noise
        buf[(i0 + j) % N] += sm * expf(-t * decay) * amp;
    }
}

static void RenderMusicLoop(void) {
    uint32_t savedRng = rngState; rngState = 5150u;
    const float step = 60.0f / MUSIC_BPM / 2.0f;                    // one eighth note, in seconds
    const int N = (int)(MUSIC_BARS * 8 * step * SR);
    float* buf = (float*)calloc(N, sizeof(float));

    for (int b = 0; b < MUSIC_BARS; b++) {
        float t0 = b * 8 * step;
        for (int s = 0; s < 8; s++) {                               // melody: hold each note until the next one
            int m = MELODY[b][s]; if (m < 0) continue;
            int nxt = s + 1; while (nxt < 8 && MELODY[b][nxt] < 0) nxt++;
            AddNote(buf, N, t0 + s * step, (nxt - s) * step * 0.92f, Midi(m), 0, 0.22f, 1.2f);
        }
        for (int s = 0; s < 8; s += 4)                              // bass on beats 1 and 3
            AddNote(buf, N, t0 + s * step, 4 * step * 0.9f, Midi(BASS_ROOT[b] + 12), 1, 0.40f, 0.8f);
        static const int MIN3[3] = { 0, 3, 7 }, MAJ3[3] = { 0, 4, 7 };
        for (int s = 0; s < 8; s += 2) {                            // quiet chord tinkle
            int c = (CHORD_MINOR[b] ? MIN3 : MAJ3)[(s / 2) % 3];
            AddNote(buf, N, t0 + s * step, 2 * step * 0.8f, Midi(BASS_ROOT[b] + 24 + c), 2, 0.07f, 3.0f);
        }
        AddKick(buf, N, t0, 0.45f); AddKick(buf, N, t0 + 4 * step, 0.30f);
        AddTick(buf, N, t0 + 4 * step, 0.12f, 0.10f, 28.0f);
    }

    // The crunchy 8-bit sound: round every sample to a small number of levels.
    for (int i = 0; i < N; i++) buf[i] = roundf(buf[i] * 64.0f) / 64.0f;

    // Echo (4 repeats, wrapping round the end of the loop).
    float* ech = (float*)malloc(N * sizeof(float));
    memcpy(ech, buf, N * sizeof(float));
    int d = (int)(0.45f * SR);
    for (int k = 1; k <= 4; k++) { float g = powf(0.42f, (float)k); for (int i = 0; i < N; i++) ech[i] += buf[((i - d * k) % N + N) % N] * g; }

    // A touch of reverb (four combs + two all-passes), run twice so the tail wraps seamlessly.
    static const int CL[4] = { 1687, 1601, 2053, 2251 }, AL[2] = { 556, 441 };
    float* cb[4]; float* ab[2]; int cp[4] = { 0, 0, 0, 0 }, ap[2] = { 0, 0 }; float damp[4] = { 0, 0, 0, 0 };
    for (int k = 0; k < 4; k++) cb[k] = (float*)calloc(CL[k], sizeof(float));
    for (int k = 0; k < 2; k++) ab[k] = (float*)calloc(AL[k], sizeof(float));
    float* mix = (float*)calloc(N, sizeof(float));
    for (int pass = 0; pass < 2; pass++)
        for (int i = 0; i < N; i++) {
            float x = ech[i], s = 0;
            for (int k = 0; k < 4; k++) {
                float y = cb[k][cp[k]];
                damp[k] += (y - damp[k]) * 0.4f;
                cb[k][cp[k]] = x * 0.3f + damp[k] * 0.84f;
                if (++cp[k] >= CL[k]) cp[k] = 0;
                s += y;
            }
            for (int k = 0; k < 2; k++) {
                float bz = ab[k][ap[k]], inp = s + bz * 0.5f;
                ab[k][ap[k]] = inp; s = bz - inp * 0.5f;
                if (++ap[k] >= AL[k]) ap[k] = 0;
            }
            if (pass == 1) mix[i] = x * 0.85f + s * 0.20f;
        }

    // Trim the very lowest rumble, tame the very top, and set the loudness.
    float hp = 0, lpo = 0, peak = 0.0001f;
    for (int pass = 0; pass < 2; pass++)
        for (int i = 0; i < N; i++) {
            hp += (mix[i] - hp) * 0.02f;
            float v = mix[i] - hp;
            lpo += (v - lpo) * 0.85f;
            if (pass == 1) { mix[i] = lpo; peak = fmaxf(peak, fabsf(lpo)); }
        }
    musicLoop = (float*)malloc(N * sizeof(float));
    musicLoopN = N;
    for (int i = 0; i < N; i++) musicLoop[i] = mix[i] / peak * 0.85f;
    for (int k = 0; k < 4; k++) free(cb[k]);
    for (int k = 0; k < 2; k++) free(ab[k]);
    free(buf); free(ech); free(mix);
    rngState = savedRng;
}

static double musicPos = 0;
static float  mGain = 0, mOpen = 1, mRate = 1, mLp = 0;

static void FillMusic(short* out, int n) {
    if (!musicLoop) { for (int i = 0; i < n; i++) out[i] = 0; return; }
    const int N = musicLoopN;
    bool playing = (gameState == STATE_PLAYING && !paused);
    float tGain = paused ? 0.45f : (gameState == STATE_GAMEOVER ? 0.55f : (gameState == STATE_TITLE ? 0.9f : 1.0f));
    float tOpen = (paused || gameState == STATE_GAMEOVER) ? 0.06f : 1.0f;      // muffled when paused / dead
    float tRate = (mode == MODE_HARD && playing) ? 1.10f : 1.0f;               // Hard: the march speeds up
    for (int i = 0; i < n; i++) {
        Slew(mGain, tGain, 0.00008f); Slew(mOpen, tOpen, 0.0004f); Slew(mRate, tRate, 0.00004f);
        int i0 = (int)musicPos; float fr = (float)(musicPos - i0); int i1 = (i0 + 1) % N;
        float v = musicLoop[i0] * (1 - fr) + musicLoop[i1] * fr;
        musicPos += mRate; if (musicPos >= N) musicPos -= N;
        Slew(mLp, v, 0.02f + 0.98f * mOpen);
        out[i] = (short)(Soft(mLp * mGain * 0.9f) * 0.8f * 30000.0f);
    }
}

// ---------------- Sound effects ----------------
enum { SFX_SOUL, SFX_POWER, SFX_HIT, SFX_BLOCK, SFX_OVER, SFX_START, SFX_THUNDER, SFX_BEAT, SFX_TICK, SFX_COUNT };

// Builds one effect's samples. t = seconds since the sound began.
static short* SynthSfx(int which, int* outCount) {
    float dur = 0.3f;
    switch (which) {
        case SFX_SOUL: dur = 0.45f; break;   case SFX_POWER: dur = 0.5f; break;
        case SFX_HIT: dur = 1.2f; break;     case SFX_BLOCK: dur = 0.35f; break;
        case SFX_OVER: dur = 2.8f; break;    case SFX_START: dur = 2.2f; break;
        case SFX_THUNDER: dur = 3.4f; break; case SFX_BEAT: dur = 0.30f; break;
        case SFX_TICK: dur = 0.06f; break;
    }
    int n = (int)(dur * SR);
    short* out = (short*)calloc(n, sizeof(short));
    *outCount = n;
    float ph = 0, ph2 = 0, ph3 = 0, lpA = 0, lpB = 0, lpC = 0;
    for (int i = 0; i < n; i++) {
        float t = i / (float)SR, v = 0;
        switch (which) {
            case SFX_SOUL: {   // happy little two-note bleep with a ghostly echo
                for (int e = 0; e < 2; e++) {
                    float tt = t - e * 0.11f; if (tt < 0) continue;
                    float f = tt < 0.07f ? 880.0f : 1320.0f;
                    float env = expf(-tt * 14.0f) * (e == 0 ? 1.0f : 0.30f);
                    float p = TAU * f * tt;
                    v += (sinf(p) + 0.35f * sinf(p * 2.0f) + 0.15f * ((fmodf(f * tt, 1.0f) < 0.5f) ? 1.0f : -1.0f)) * env * 0.35f;
                }
            } break;
            case SFX_POWER: {  // rising sparkle arpeggio
                static const float fr[4] = { 523.3f, 659.3f, 784.0f, 1046.5f };
                for (int k = 0; k < 4; k++) {
                    float tt = t - k * 0.07f; if (tt < 0) continue;
                    v += sinf(TAU * fr[k] * tt) * expf(-tt * 9.0f) * 0.28f;
                }
            } break;
            case SFX_HIT: {    // DOOM: sub-bass drop + distorted growl + noise crack
                float f = 38.0f + 120.0f * expf(-t * 4.5f);
                ph += TAU * f / SR; ph2 += TAU * 82.4f / SR; ph3 += TAU * 116.5f / SR;   // low E and a tritone
                float saw1 = fmodf(ph2 / TAU, 1.0f) * 2 - 1, saw2 = fmodf(ph3 / TAU, 1.0f) * 2 - 1;
                lpA += ((saw1 + saw2) * 0.5f - lpA) * 0.12f;
                lpB += (Noise() - lpB) * 0.25f;
                float env = expf(-t * 2.4f) * fminf(1.0f, t * 400.0f);
                v = Soft(3.2f * (sinf(ph) * 0.9f + lpA * 0.55f) + lpB * 2.0f * expf(-t * 16.0f)) * env * 0.9f;
            } break;
            case SFX_BLOCK: {  // metallic ping
                float env = expf(-t * 13.0f);
                v = (sinf(TAU * 1250.0f * t) + 0.7f * sinf(TAU * 1870.0f * t) + 0.4f * sinf(TAU * 3100.0f * t)) * env * 0.25f;
                v += Noise() * expf(-t * 90.0f) * 0.3f;
            } break;
            case SFX_OVER: {   // slow, sinking minor chord
                float sink = 1.0f - 0.45f * (t / dur);
                float env = expf(-t * 0.9f) * fminf(1.0f, t * 30.0f);
                static const float fr[3] = { 110.0f, 130.8f, 164.8f };
                float s = 0;
                for (int k = 0; k < 3; k++) { s += sinf(TAU * fr[k] * sink * t + k) + 0.4f * sinf(TAU * fr[k] * 2 * sink * t); }
                lpA += (Noise() - lpA) * 0.03f;
                v = Soft(s * 0.35f + lpA * 3.0f) * env * 0.7f;
            } break;
            case SFX_START: {  // low funeral bell
                float env = expf(-t * 1.8f) * fminf(1.0f, t * 300.0f);
                v = (sinf(TAU * 196.0f * t) + 0.6f * sinf(TAU * 196.0f * 2.0f * t) * expf(-t * 1.0f) + 0.5f * sinf(TAU * 196.0f * 2.76f * t) * expf(-t * 2.5f)
                     + 0.3f * sinf(TAU * 196.0f * 5.4f * t) * expf(-t * 4.0f)) * env * 0.4f;
            } break;
            case SFX_THUNDER: {
                lpA += (Noise() - lpA) * 0.05f; lpB += (lpA - lpB) * 0.05f; lpC += (lpB - lpC) * 0.2f;
                float roll = 0.6f + 0.4f * sinf(t * 7.0f + sinf(t * 2.3f) * 2.0f);
                float env = fminf(1.0f, t * 12.0f) * expf(-t * 0.9f) * roll;
                ph += TAU * 42.0f / SR;
                v = Soft(lpB * 22.0f + sinf(ph) * 0.4f) * env * 0.85f;
            } break;
            case SFX_BEAT: {   // lub-dub
                float a = sinf(TAU * 85.0f * t) * expf(-t * 24.0f);
                float tt = t - 0.14f; float b = tt > 0 ? sinf(TAU * 70.0f * tt) * expf(-tt * 28.0f) * 0.7f : 0.0f;
                v = (a + b) * 0.7f;
            } break;
            case SFX_TICK: v = ((fmodf(t * 520.0f, 1.0f) < 0.5f) ? 1.0f : -1.0f) * expf(-t * 60.0f) * 0.25f; break;
        }
        out[i] = (short)(Clampf(v, -1.0f, 1.0f) * 30000.0f);
    }
    return out;
}

static Sound sfx[SFX_COUNT];
static AudioStream musicStream, ambStream;
static Music rainMusic;                  // the looping rain sound from rain.wav
static Music bgMusic;                    // the music loaded from music.wav (best quality)
static bool  musicFromFile = false;      // false = fall back to the tune the code builds itself
static float fileGain = 0.0f;
static void ApplyMusicVolume(void) {         // used by the music mute button
    if (!audioOK) return;
    if (musicFromFile) SetMusicVolume(bgMusic, musicMuted ? 0.0f : 0.7f * fileGain);
    else SetAudioStreamVolume(musicStream, musicMuted ? 0.0f : 0.65f);
}
static short musicBuf[AUDIO_HALF], ambBuf[AUDIO_HALF];

static void InitAudio(void) {
    InitAudioDevice();
    audioOK = IsAudioDeviceReady();
    if (!audioOK) return;
    SetMasterVolume(0.8f);
    // Try to load the music file first. In the web build it is packed into the game (--preload-file music.wav).
    bgMusic = LoadMusicStream("music.wav");
    musicFromFile = IsMusicValid(bgMusic);
    if (musicFromFile) { bgMusic.looping = true; PlayMusicStream(bgMusic); }
    else RenderMusicLoop();                // no file? build a tune with code instead (takes a moment)
    rainMusic = LoadMusicStream("rain.wav");   // the rain sound (packed in with --preload-file rain.wav)
    rainFromFile = IsMusicValid(rainMusic);
    if (rainFromFile) { rainMusic.looping = true; PlayMusicStream(rainMusic); }
    for (int k = 0; k < SFX_COUNT; k++) {
        int count = 0;
        short* d = SynthSfx(k, &count);
        Wave w = { (unsigned int)count, (unsigned int)SR, 16, 1, d };
        sfx[k] = LoadSoundFromWave(w);       // raylib copies the data, so we can free ours
        free(d);
    }
    SetAudioStreamBufferSizeDefault(AUDIO_HALF * 2);
    ambStream   = LoadAudioStream(SR, 16, 1);
    SetAudioStreamVolume(ambStream, 0.85f);
    if (!musicFromFile) {
        musicStream = LoadAudioStream(SR, 16, 1);
        SetAudioStreamVolume(musicStream, 0.65f);
    }
    for (int k = 0; k < 2; k++) {            // pre-fill both halves of each stream, then start
        if (!musicFromFile) { FillMusic(musicBuf, AUDIO_HALF); UpdateAudioStream(musicStream, musicBuf, AUDIO_HALF); }
        FillAmbient(ambBuf, AUDIO_HALF);   UpdateAudioStream(ambStream, ambBuf, AUDIO_HALF);
    }
    if (!musicFromFile) PlayAudioStream(musicStream);
    PlayAudioStream(ambStream);
}

static void PlaySfx(int which, float pitch, float vol) {
    if (!audioOK) return;
    SetSoundPitch(sfx[which], pitch);
    SetSoundVolume(sfx[which], vol);
    PlaySound(sfx[which]);
}

// Called once per frame: refills the music + weather streams and times the thunder / heartbeat.
static void UpdateAudio(float dt) {
    if (!audioOK) return;
    if (musicFromFile) {                      // music.wav: raylib streams it; we just set loudness + speed by game state
        bool playing = (gameState == STATE_PLAYING && !paused);
        float tGain = paused ? 0.40f : (gameState == STATE_GAMEOVER ? 0.5f : (gameState == STATE_TITLE ? 0.9f : 1.0f));
        fileGain += (tGain - fileGain) * (1.0f - expf(-3.0f * dt));
        ApplyMusicVolume();
        SetMusicPitch(bgMusic, (mode == MODE_HARD && playing) ? 1.1f : 1.0f);   // Hard: the march speeds up
        UpdateMusicStream(bgMusic);
    }
    if (rainFromFile) {                       // rain.wav: loudness follows the weather (fades in and out smoothly)
        SetMusicVolume(rainMusic, 0.6f * amb.rain);
        UpdateMusicStream(rainMusic);
    }
    for (int k = 0; k < 2; k++) {
        if (!musicFromFile && IsAudioStreamProcessed(musicStream)) { FillMusic(musicBuf, AUDIO_HALF); UpdateAudioStream(musicStream, musicBuf, AUDIO_HALF); }
        if (IsAudioStreamProcessed(ambStream))   { FillAmbient(ambBuf, AUDIO_HALF); UpdateAudioStream(ambStream, ambBuf, AUDIO_HALF); }
    }
    if (thunderTimer >= 0) {                  // thunder arrives a moment after the lightning
        thunderTimer -= dt;
        if (thunderTimer < 0) { PlaySfx(SFX_THUNDER, RandF(0.85f, 1.15f), 0.9f); thunderTimer = -1; }
    }
    if (gameState == STATE_PLAYING && !paused && (player.lives == 1 || mode == MODE_HARD)) {   // heartbeat: last flame, and always in Hard
        beatTimer -= dt;
        if (beatTimer <= 0) { beatTimer = (player.lives == 1) ? 0.9f : 1.1f; PlaySfx(SFX_BEAT, 1.0f, player.lives == 1 ? 0.8f : 0.45f); }
    }
}

// ---------------------------------------------------------------------
// 5. GAME LOGIC
// ---------------------------------------------------------------------
static void ResetGame(void) {
    player = (Player){ SCREEN_W / 2.0f, 0, 3, 0, 0, false };
    player.lives = MODES[mode].lives;
    itemsCount = 0; sparksCount = 0; popupsCount = 0;
    score = 0; combo = 0; playTime = 0;
    hazardTimer = 1.0f; coinTimer = 0.4f;
    powerTimer = RandF(6.0f, 9.0f) * MODES[mode].powerMul;
    for (int i = 0; i < P_COUNT; i++) buff[i] = 0;
    shake = 0; hitFlash = 0; paused = false; newBest = false;
}

// Build all the background scenery once, at random.
static void InitVisuals(void) {
    for (int i = 0; i < 180; i++)
        { float a = RandF(0, VW), b = RandF(0, GV), c = RandF(220, 380), d = RandF(1.0f, 2.2f), e = RandF(0, 6.28f); PUSH(drops, (Drop){ a, b, c, d, e }); }
    for (int i = 0; i < 6; i++)
        { float a = RandF(0, VW), b = RandF(14, 95), c = RandF(0.5f, 1.1f), d = RandF(3, 9); PUSH(clouds, (Cloud){ a, b, c, d }); }
    for (int i = 0; i < 9; i++)
        { float a = RandF(-50, VW), b = RandF(GV - 30, GV + 14), c = RandF(110, 190), d = RandF(3, 9); PUSH(fogs, (Fog){ a, b, c, d }); }
    for (int i = 0; i < 70; i++)
        { float a = RandF(0, VW), b = RandF(0, 165), c = RandF(0.5f, 1.5f), d = RandF(0, 6.28f); PUSH(stars, (Star){ a, b, c, d }); }
    for (int i = 0; i < 4; i++)
        { float a = RandF(0, VW), b = RandF(30, 130), c = RandF(18, 35), d = RandF(0, 6.28f); PUSH(bgBats, (BgBat){ a, b, c, d }); }

    // Tombstones spread along the ground, a mix of shapes.
    int x = 14;
    while (x < VW - 10) {
        { int dy = GetRandomValue(0, 3), type = GetRandomValue(0, 2); PUSH(tombs, (Tomb){ x, dy, type }); }
        x += GetRandomValue(28, 64);
    }

    // Tufts of grass dotted over the ground.
    for (int i = 0; i < 46; i++)
        { int a = GetRandomValue(0, VW - 1), b = GetRandomValue(GV + 9, VH - 2), c = GetRandomValue(1, 2), d = GetRandomValue(0, 2); PUSH(grass, (Grass){ a, b, c, d }); }
    for (int x = 0; x < VW; x++) {
        int r = GetRandomValue(0, 9);
        dripLen[x] = (r < 4) ? 2 : (r < 8 ? 3 : 5);
        if (x > 0 && dripLen[x - 1] == 5 && GetRandomValue(0, 1)) dripLen[x] = 4;   // drips come in clumps
    }

    // Pairs of eyes watching from the dark.
    PUSH(eyes, (EyePair){ 56, GV - 56, 0.0f });
    PUSH(eyes, (EyePair){ 350, GV - 75, 2.0f });
    PUSH(eyes, (EyePair){ 203, GV - 30, 4.0f });
}

// Create a burst of sparks at a canvas position.
static void Burst(Vector2 canvasPos, Color c, int n) {
    for (int i = 0; i < n; i++) {
        float a = RandF(0, 6.28f), s = RandF(30, 120);
        PUSH(sparks, (Spark){ canvasPos, { cosf(a) * s, sinf(a) * s - 30 }, RandF(0.4f, 0.8f), c });
    }
}

static void AddPopup(Vector2 logicPos, const char* text, Color c) {
    Popup p = { { (float)V(logicPos.x), (float)V(logicPos.y) }, 0.9f, "", c };
    snprintf(p.text, sizeof(p.text), "%s", text);
    PUSH(popups, p);
}

// Smoothly fade the night toward the current weather, and move the
// rain / clouds / fog / bats / lightning. Runs on every screen.
static void UpdateVisuals(float dt) {
    WeatherRules R = RULES[weather.type];
    float k = 1.0f - expf(-3.0f * dt);   // smooth blend factor
    bool hard = (mode == MODE_HARD);

    vSkyTop    = Approach(vSkyTop,    hard ? HardTint(R.skyTop)    : R.skyTop,    k);
    vSkyBottom = Approach(vSkyBottom, hard ? HardTint(R.skyBottom) : R.skyBottom, k);
    vGround    = Approach(vGround,    R.ground,    k);
    vCloud     = Approach(vCloud,     R.cloud,     k);
    vCloudAlpha += (R.cloudAlpha - vCloudAlpha) * k;
    vFogAlpha   += (R.fogAlpha   - vFogAlpha)   * k;
    vMoonAlpha  += ((weather.type == W_CLEAR ? 1.0f : (weather.type == W_CLOUDY ? 0.22f : 0.0f)) - vMoonAlpha) * k;
    vBlood      += ((hard ? 1.0f : 0.0f) - vBlood) * k;

    float windVisual = WindPush() * 1.5f;   // how far particles drift sideways (canvas pixels/sec)

    // Rain and snow
    for (int i = 0; i < R.particles && i < dropsCount; i++) {
        Drop* d = &drops[i];
        if (weather.type == W_SNOW) {
            d->y += d->speed * 0.2f * dt;
            d->x += (sinf(totalTime * 1.5f + d->phase) * 12.0f + windVisual) * dt;
        } else {
            d->y += d->speed * dt;
            d->x += windVisual * dt;
        }
        if (d->y > GV) { d->y = -5; d->x = RandF(-25, VW + 25); }
        if (d->x < -30) d->x = VW + 25;
        if (d->x > VW + 30) d->x = -25;
    }

    // Clouds and fog drift with the wind
    for (int ci = 0; ci < cloudsCount; ci++) {
        Cloud* c = &clouds[ci];
        c->x += (c->speed + WindPush() * 0.3f) * dt;
        if (c->x > VW + 90) c->x = -90;
        if (c->x < -100) c->x = VW + 85;
    }
    for (int fi = 0; fi < fogsCount; fi++) {
        Fog* f = &fogs[fi];
        f->x += (f->speed + WindPush() * 0.4f) * dt;
        if (f->x > VW + f->w) f->x = -f->w;
        if (f->x < -f->w - 10) f->x = VW + f->w;
    }

    // Distant bats flutter across the sky
    for (int bi = 0; bi < bgBatsCount; bi++) {
        BgBat* b = &bgBats[bi];
        b->x += b->speed * dt;
        b->phase += dt * 9.0f;
        b->y += sinf(b->phase * 0.35f) * 9.0f * dt;
        if (b->x > VW + 15) { b->x = -15; b->y = RandF(30, 130); }
    }

    // Lightning
    if (weather.type == W_STORM) {
        lightningTimer -= dt;
        if (lightningTimer <= 0) {
            lightningTimer = RandF(1.5f, 4.0f);
            flash = 1.0f;
            thunderTimer = RandF(0.2f, 0.9f);
            // Build a zig-zag line from the sky to the ground.
            boltCount = 0;
            float x = RandF(50, VW - 50), y = 0;
            PUSH(bolt, (Vector2){ x, y });
            while (y < GV) {
                y += RandF(20, 40);
                x += RandF(-22, 22);
                PUSH(bolt, (Vector2){ x, MINV(y, (float)GV) });
            }
        }
    }
    flash = MAXV(0.0f, flash - 2.5f * dt);
    hitFlash = MAXV(0.0f, hitFlash - 2.2f * dt);
}

// Choose which power-up to drop. A heart only drops if you are missing a flame.
static int PickPower(void) {
    for (int tries = 0; tries < 20; tries++) {
        int p = GetRandomValue(0, P_COUNT - 1);
        if (p == P_HEAL && player.lives >= MODES[mode].lives) continue;
        if (p == P_SHIELD && player.shield) continue;
        return p;
    }
    return P_SLOW;
}

// You collected a power-up!
static void ApplyPower(int p, Vector2 at) {
    PlaySfx(SFX_POWER, 1.0f, 1.0f);
    PowerInfo info = POWERS[p];
    if (p == P_HEAL)        player.lives = MINV(MODES[mode].lives, player.lives + 1);
    else if (p == P_SHIELD) player.shield = true;
    else                    buff[p] = info.duration;
    Burst((Vector2){ (float)V(at.x), (float)V(at.y) }, info.color, 16);
    AddPopup(at, info.name, info.color);
}

static void UpdatePlaying(float dt) {
    WeatherRules R = RULES[weather.type];
    ModeRules M = MODES[mode];
    playTime += dt;
    player.bob += dt * 8.0f;

    // Timed power-ups tick down.
    for (int i = 0; i < P_COUNT; i++) if (buff[i] > 0) buff[i] -= dt;

    // ---- Player movement ----
    // Input is -1 (left), 0, or +1 (right).
    float input = 0;
    if (IsKeyDown(KEY_LEFT)  || IsKeyDown(KEY_A)) input -= 1;
    if (IsKeyDown(KEY_RIGHT) || IsKeyDown(KEY_D)) input += 1;

    // Speed up from input + wind, then slow down from friction.
    // Low friction (rain) = you keep sliding. High friction = snappy.
    player.vx += (input * R.accel) * dt;   // the wind no longer pushes the keeper - only the falling things
    if (input == 0 && fabsf(player.vx) < 12.0f) player.vx = 0;   // come to a clean stop
    player.vx -= player.vx * R.friction * dt;
    player.x  += player.vx * dt;

    // Stay inside the screen.
    if (player.x < 46)            { player.x = 46;            player.vx = 0; }
    if (player.x > SCREEN_W - 46) { player.x = SCREEN_W - 46; player.vx = 0; }

    if (player.invuln > 0) player.invuln -= dt;

    // ---- Spawning ----
    // The game gets harder the longer you survive (Hard mode ramps up faster).
    float difficulty = MINV(playTime / M.rampSeconds, 1.0f);     // 0 -> 1

    hazardTimer -= dt;
    if (hazardTimer <= 0) {
        float interval = (1.05f - 0.65f * difficulty) / (R.hazardRate * M.hazardMul);
        hazardTimer = interval * RandF(0.7f, 1.3f);
        int kind = GetRandomValue(0, 1) ? K_SKULL : K_BAT;       // skull or bat, 50/50
        float px = RandF(30, SCREEN_W - 30), sp = RandF(0, 6.28f);
        PUSH(items, (Item){ { px, -20 }, kind == K_SKULL ? 18.0f : 17.0f,
                          (170 + 130 * difficulty) * R.fallSpeed * M.fallMul, sp, true, HAZARD_GLOW, kind, 0 });
    }

    coinTimer -= dt;
    if (coinTimer <= 0) {
        coinTimer = RandF(0.55f, 1.0f);
        float px = RandF(30, SCREEN_W - 30), sp = RandF(0, 6.28f);
        PUSH(items, (Item){ { px, -20 }, 13, 160 * R.fallSpeed,
                          sp, false, { 120, 255, 225, 255 }, K_SOUL, 0 });
    }

    powerTimer -= dt;
    if (powerTimer <= 0) {
        powerTimer = RandF(11.0f, 17.0f) * M.powerMul;
        int p = PickPower();
        float px = RandF(60, SCREEN_W - 60), sp = RandF(0, 6.28f);
        PUSH(items, (Item){ { px, -20 }, 15, 110 * R.fallSpeed,
                          sp, false, POWERS[p].color, K_POWER, p });
    }

    // ---- Update falling items ----
    // The lantern light is our "hitbox": the area that catches things.
    // (You can see it as a dotted ring around the lantern.)
    float hitW = (buff[P_WIDE] > 0) ? 150.0f : 88.0f;
    Rectangle hitbox = { player.x - hitW / 2, GROUND_Y - 124, hitW, 62 };
    Vector2 lantern = { player.x, GROUND_Y - 93 };
    float drift = WindPush() * 1.5f;                       // wind pushes falling things sideways
    float idt = (buff[P_SLOW] > 0) ? dt * 0.5f : dt;       // Slow Time makes everything fall slower

    for (int i = 0; i < itemsCount; ) {
        Item* it = &items[i];

        // Soul Magnet: nearby souls fly toward the lantern.
        if (buff[P_MAGNET] > 0 && it->kind == K_SOUL) {
            Vector2 d = { lantern.x - it->pos.x, lantern.y - it->pos.y };
            float dist = sqrtf(d.x * d.x + d.y * d.y);
            if (dist < 280 && dist > 1) {
                float pull = 260.0f + (280.0f - dist);
                it->pos.x += d.x / dist * pull * dt;
                it->pos.y += d.y / dist * pull * dt;
            }
        }

        it->pos.y += it->vy * idt;
        it->pos.x += drift * idt;
        it->spin  += idt * 6.0f;
        if (it->kind == K_BAT) it->pos.x += sinf(it->spin * 0.7f) * 75.0f * (mode == MODE_HARD ? 1.4f : 1.0f) * idt;   // bats wobble
        bool remove = false;
        Vector2 cpos = { (float)V(it->pos.x), (float)V(it->pos.y) };   // canvas position, for effects

        if (CheckCollisionCircleRec(it->pos, it->radius, hitbox)) {
            remove = true;
            if (it->hazard) {
                if (player.invuln <= 0) {
                    if (player.shield) {                  // the Ward absorbs it
                        player.shield = false;
                        player.invuln = 0.8f;
                        shake = 6;
                        PlaySfx(SFX_BLOCK, 1.0f, 1.0f);
                        Burst(cpos, POWERS[P_SHIELD].color, 20);
                        AddPopup(it->pos, "BLOCKED!", POWERS[P_SHIELD].color);
                    } else {                              // ouch - lose a flame
                        player.lives--;
                        PlaySfx(SFX_HIT, it->kind == K_BAT ? 1.3f : 0.85f, 1.0f);       // doom!
                        player.invuln = 1.3f;
                        shake = 10;
                        hitFlash = 1.0f;
                        combo = 0;
                        Burst(cpos, it->color, 22);
                        AddPopup(it->pos, "CURSED!", (Color){ 255, 70, 70, 255 });
                    }
                }
            } else if (it->kind == K_POWER) {
                ApplyPower(it->power, it->pos);
            } else {                                       // soul caught!
                combo++;
                PlaySfx(SFX_SOUL, 1.0f + 0.04f * MINV(combo, 12), 1.0f);   // bleep, higher with a bigger chain
                int mult = 1 + MINV(combo, 20) / 5;            // x1 ... x5
                int pts = R.coinPoints * mult * M.scoreMul;
                score += pts;
                Burst(cpos, it->color, 10);
                char buf[24];
                snprintf(buf, sizeof(buf), "+%d", pts);
                AddPopup(it->pos, buf, (Color){ 170, 255, 235, 255 });
            }
        } else if (it->pos.y > GROUND_Y + 10) {
            remove = true;
            if (it->kind == K_SOUL) combo = 0;             // missed a soul = chain lost
            else if (it->hazard) Burst((Vector2){ cpos.x, (float)GV }, Fade(it->color, 0.8f), 6);   // splat
        }

        if (remove) { items[i] = items[itemsCount - 1]; itemsCount--; }
        else i++;
    }

    // ---- Game over? ----
    if (player.lives <= 0) {
        gameState = STATE_GAMEOVER;
        PlaySfx(SFX_OVER, 1.0f, 1.0f);
        newBest = score > bestScore[mode];
        if (newBest) bestScore[mode] = score;
    }
}

// Sparks, popups and screen shake keep animating on every screen.
static void UpdateEffects(float dt) {
    for (int i = 0; i < sparksCount; ) {
        Spark* s = &sparks[i];
        s->life -= dt;
        s->vel.y += 200 * dt;            // gravity
        s->pos.x += s->vel.x * dt;
        s->pos.y += s->vel.y * dt;
        if (s->life <= 0) { sparks[i] = sparks[sparksCount - 1]; sparksCount--; } else i++;
    }
    for (int i = 0; i < popupsCount; ) {
        Popup* p = &popups[i];
        p->life -= dt;
        p->pos.y -= 22 * dt;
        if (p->life <= 0) { popups[i] = popups[popupsCount - 1]; popupsCount--; } else i++;
    }
    shake = MAXV(0.0f, shake - 40.0f * dt);
}

// ---------------------------------------------------------------------
// 6. DRAWING  (everything below draws onto the small 400x300 canvas)
// ---------------------------------------------------------------------

// The sky: a gradient made of flat bands, which looks like old-school pixel art.
// Dusk sky: top -> pink middle -> horizon glow, with ordered (Bayer) dithering between colour bands.
// It is painted into a texture only when the colours change, so it costs nothing most frames.
static void DrawSky(void) {
    Vector3 mid = Lerp3(Lerp3(vSkyTop, vSkyBottom, 0.5f), (Vector3){ 200, 70, 120 }, 0.22f);
    Color ct = ToColor(vSkyTop, 1.0f, 255), cm = ToColor(mid, 1.0f, 255), cb = ToColor(vSkyBottom, 1.0f, 255);
    unsigned key = (ct.r * 31u + ct.g * 17u + ct.b * 13u) ^ (cm.r * 7u + cm.g * 5u + cm.b * 3u) ^ ((cb.r * 29u + cb.g * 23u + cb.b * 19u) << 5);
    if (!skyPix) {
        skyPix = (Color*)calloc(VW * VH, sizeof(Color));
        Image im = { skyPix, VW, VH, 1, PIXELFORMAT_UNCOMPRESSED_R8G8B8A8 };
        skyTex = LoadTextureFromImage(im);
    }
    if (key != skyKey) {
        skyKey = key;
        static const int bayer[4][4] = { {0,8,2,10},{12,4,14,6},{3,11,1,9},{15,7,13,5} };
        const int bands = 9;
        for (int y = 0; y < VH; y++) {
            float t = Clampf(y / (float)GV, 0, 1);
            float f = t * bands;
            int i = (int)f; float frac = f - i;
            for (int x = 0; x < VW; x++) {
                float thr = (bayer[y & 3][x & 3] + 0.5f) / 16.0f;
                int idx = i + (frac > thr ? 1 : 0);
                float u = Clampf(idx / (float)bands, 0, 1);
                Color c = (u < 0.5f) ? ToColor(Lerp3(vSkyTop, mid, u * 2), 1.0f, 255) : ToColor(Lerp3(mid, vSkyBottom, (u - 0.5f) * 2), 1.0f, 255);
                skyPix[y * VW + x] = c;
            }
        }
        UpdateTexture(skyTex, skyPix);
    }
    DrawTexture(skyTex, 0, 0, WHITE);
}

static void DrawStars(void) {
    FOREACH(Star, s, stars) {
        float tw = 0.5f + 0.5f * sinf(totalTime * 2.0f + s.phase);
        int size = s.size > 1.1f ? 2 : 1;
        DrawRectangle((int)s.x, (int)s.y, size, size, Fade(WHITE, vMoonAlpha * (0.35f + 0.6f * tw)));
    }
}

static void DrawMoon(void) {
    if (vMoonAlpha < 0.02f) return;
    int cx = 335, cy = 52;
    // Normal moon is pale; Hard mode fades it to a blood moon.
    Vector3 body  = Lerp3((Vector3){ 232, 232, 210 }, (Vector3){ 236, 70, 60 }, vBlood);
    Vector3 crat  = Lerp3((Vector3){ 204, 204, 184 }, (Vector3){ 190, 46, 44 }, vBlood);
    Vector3 glowc = Lerp3((Vector3){ 150, 170, 230 }, (Vector3){ 230, 60, 50 }, vBlood);
    DrawGlow(cx, cy, 75, Fade(ToColor(glowc, 1.0f, 255), vMoonAlpha), 0.9f);
    DrawCircle(cx, cy, 20, Fade(ToColor(body, 1.0f, 255), vMoonAlpha));
    DrawCircle(cx - 6, cy - 4, 4, Fade(ToColor(crat, 1.0f, 255), vMoonAlpha));      // craters
    DrawCircle(cx + 7, cy + 5, 3, Fade(ToColor(crat, 1.0f, 255), vMoonAlpha));
    DrawCircle(cx + 3, cy - 9, 2, Fade(ToColor(crat, 1.0f, 255), vMoonAlpha));
    DrawCircle(cx - 7, cy + 8, 2, Fade(ToColor(crat, 1.0f, 255), vMoonAlpha));
}

static void DrawClouds(void) {
    // Clouds are drawn as solid colour (not see-through) so overlapping puffs don't show seams.
    Vector3 skyMid = Lerp3(vSkyTop, vSkyBottom, 0.35f);
    Color col = ToColor(Lerp3(skyMid, vCloud, Clampf(vCloudAlpha, 0, 1)), 1.0f, 255);
    FOREACH(Cloud, c, clouds) {
        float s = c.scale;
        int x = (int)c.x, y = (int)c.y;
        DrawCircle(x,                 y,                 (float)(int)(14 * s), col);
        DrawCircle(x + (int)(15 * s), y - (int)(7 * s),  (float)(int)(17 * s), col);
        DrawCircle(x + (int)(33 * s), y,                 (float)(int)(14 * s), col);
        DrawCircle(x + (int)(16 * s), y + (int)(4 * s),  (float)(int)(15 * s), col);
    }
}

// A gnarled dead tree. 'dir' = +1 leans its branches to the right, -1 to the left.
static void DrawDeadTree(int x, int h, int dir) {
    Color wood = { 14, 9, 22, 255 };
    Color rim  = { 74, 40, 70, 255 };          // sunset catching the edge of the bark
    // roots + trunk (a lighter rim line on the sunset side)
    PixLine(x - 6 * dir, GV + 1, x - 1 * dir, GV - 8, 3, wood);
    PixLine(x + 6 * dir, GV + 1, x + 1 * dir, GV - 8, 3, wood);
    PixLine(x, GV, x + dir, GV - h, 7, wood);
    PixLine(x + 3 * dir, GV - 4, x + 3 * dir + dir, GV - h + 6, 1, rim);
    // hollow in the trunk
    DrawRectangle(x - 1, GV - h / 3 - 4, 3, 5, (Color){ 4, 2, 8, 255 });
    DrawRectangle(x, GV - h / 3 - 3, 1, 1, (Color){ 255, 150, 60, 255 });
    // big branches (each one forks twice)
    struct Br { int sy, dx, dy, t; };
    struct Br b[] = { {h - 20, 22, -26, 4}, {h - 36, -20, -22, 4}, {h - 6, -8, -24, 3}, {h * 2 / 3, 24, -12, 3} };
    for (int bi_ = 0; bi_ < 4; bi_++) { struct Br br = b[bi_];
        int x0 = x + dir, y0 = GV - br.sy;
        int x1 = x0 + br.dx * dir, y1 = y0 + br.dy;
        PixLine(x0, y0, x1, y1, br.t, wood);
        PixLine(x1, y1, x1 + 7 * dir, y1 - 12, 2, wood);
        PixLine(x1, y1, x1 + 12 * dir, y1 - 4, 2, wood);
        PixLine(x1 + 7 * dir, y1 - 12, x1 + 9 * dir, y1 - 20, 1, wood);
        PixLine(x1 + 12 * dir, y1 - 4, x1 + 19 * dir, y1 - 8, 1, wood);
        PixLine(x1 + 12 * dir, y1 - 4, x1 + 16 * dir, y1 + 2, 1, wood);
    }
}

// An iron fence: posts with spear tips and thin bars, running across the whole graveyard.
static void DrawFence(void) {
    Color iron = { 16, 11, 26, 255 };
    Color rim  = { 70, 44, 78, 255 };
    int top = GV - 24;
    DrawRectangle(0, top + 6,  VW, 2, iron);        // top rail
    DrawRectangle(0, GV - 7,   VW, 2, iron);        // bottom rail
    for (int x = 2; x < VW; x += 6) {
        DrawRectangle(x, top + 3, 1, 27, iron);     // bar
        DrawRectangle(x, top + 1, 1, 2, iron);      // spear tip
        DrawRectangle(x - 1, top + 3, 3, 1, iron);
    }
    for (int x = 2; x < VW; x += 36) {              // thicker posts with a ball on top
        DrawRectangle(x - 1, top - 2, 3, 32, iron);
        DrawRectangle(x - 2, top - 4, 5, 3, iron);
        DrawRectangle(x, top - 3, 1, 1, rim);
        DrawRectangle(x, top + 8, 1, 14, rim);
    }
}

// A street lamp that glows warm against the dusk.
static void DrawLampPost(int x, float phase) {
    Color iron = { 16, 11, 26, 255 };
    float fl = 0.85f + 0.15f * sinf(totalTime * 9.0f + phase) * sinf(totalTime * 3.1f + phase);
    int top = GV - 62;
    DrawGlow(x, top + 4, (int)(26 * fl), (Color){ 255, 170, 70, 255 }, 0.55f);
    DrawRectangle(x - 1, top + 10, 3, 62, iron);                 // pole
    DrawRectangle(x - 3, GV - 8,  7, 8, iron);                    // base
    DrawRectangle(x - 2, top + 8, 5, 3, iron);                    // collar
    DrawRectangle(x - 4, top - 3, 9, 2, iron);                    // roof
    DrawRectangle(x - 2, top - 5, 5, 2, iron);
    DrawRectangle(x - 1, top - 7, 3, 2, iron);
    DrawRectangle(x - 4, top - 1, 1, 9, iron);                    // cage
    DrawRectangle(x + 4, top - 1, 1, 9, iron);
    DrawRectangle(x - 3, top - 1, 7, 9, (Color){ 255, 205, 110, 255 });  // lit glass
    DrawRectangle(x - 2, top + 1, 5, 5, (Color){ 255, 240, 190, 255 });
    DrawRectangle(x - 4, top + 8, 9, 2, iron);
}

// A black cat sitting on a fence post, watching. Its tail swishes and its eyes blink.
static void DrawCat(int cx, int baseY) {
    static const char* rows[] = {
        "k..k.....",
        "kk.kk....",
        "kkkkk....",
        "kekkek...",
        "kkkkk....",
        ".kkkk....",
        "kkkkkk...",
        "kkkkkkk..",
        "kkkkkkk..",
        "kkkkkkkk.",
        "kkkkkkkk.",
    };
    Color k = { 6, 4, 10, 255 }, rim = { 74, 40, 70, 255 };
    int x0 = cx - 4, y0 = baseY - 11;
    for (int r = 0; r < 11; r++)
        for (int c = 0; c < 9; c++) {
            char ch = rows[r][c];
            if (ch == 'k') DrawRectangle(x0 + c, y0 + r, 1, 1, k);
        }
    DrawRectangle(x0 + 7, y0 + 7, 1, 3, rim);                                  // sunset rim on the back
    bool open = fmodf(totalTime, 5.0f) < 4.7f;                                 // blinks now and then
    Color eye = open ? (Color){ 200, 255, 90, 255 } : k;
    DrawRectangle(x0 + 1, y0 + 3, 1, 1, eye);
    DrawRectangle(x0 + 4, y0 + 3, 1, 1, eye);
    int sway = (int)(sinf(totalTime * 1.8f) * 3.0f);                           // tail swish
    PixLine(x0 + 8, baseY - 2, x0 + 12, baseY - 3, 2, k);
    PixLine(x0 + 12, baseY - 3, x0 + 13 + sway, baseY - 11, 2, k);
}

// Far hills, silhouettes, trees, fence, lamps, eyes, bats and the tombstones in front.
static void DrawScenery(void) {
    Color hill = ToColor(vSkyTop, 0.62f, 255);
    DrawCircle(60,  GV + 75, 105, hill);
    DrawCircle(215, GV + 95, 118, hill);
    DrawCircle(360, GV + 70, 100, hill);

    // Far-away tombstone silhouettes, drawn before the fence so they look distant.
    Color far = ToColor(vSkyTop, 0.42f, 255);
    for (int i = 0; i < 12; i++) {
        int fx = 20 + i * 34 + (i * 37) % 11, fh = 12 + (i * 53) % 9;
        DrawRectangle(fx - 4, GV - fh - 4, 9, fh, far);
        DrawCircle(fx, GV - fh - 4, 4.5f, far);
        if (i % 3 == 0) { DrawRectangle(fx, GV - fh - 14, 1, 8, far); DrawRectangle(fx - 3, GV - fh - 11, 7, 1, far); }
    }

    DrawDeadTree(46, 78, 1);
    DrawDeadTree(354, 92, -1);

    // Eyes blinking in the dark
    FOREACH(EyePair, e, eyes) {
        float cycle = fmodf(totalTime + e.offset, 6.0f);
        if (cycle > 5.6f) continue;                        // blink!
        float a = 0.7f + 0.3f * sinf(totalTime * 3.0f + e.offset);
        DrawGlow(e.x, e.y, 9, Fade((Color){ 255, 40, 40, 255 }, a), 1.0f);
        DrawRectangle(e.x - 3, e.y, 2, 2, Fade((Color){ 255, 80, 60, 255 }, a));
        DrawRectangle(e.x + 2, e.y, 2, 2, Fade((Color){ 255, 80, 60, 255 }, a));
    }

    // Little silhouette bats far away
    FOREACH(BgBat, b, bgBats) {
        int f = sinf(b.phase) > 0 ? -2 : 1;
        Color c = { 10, 6, 18, 255 };
        int bx = (int)b.x, by = (int)b.y;
        PixLine(bx - 5, by + f, bx - 1, by, 1, c);
        PixLine(bx + 5, by + f, bx + 1, by, 1, c);
        DrawRectangle(bx - 1, by, 3, 2, c);
    }

    DrawFence();
    DrawCat(218, GV - 28);
    DrawLampPost(128, 0.0f);
    DrawLampPost(282, 2.0f);

    // Tombstones (drawn before the ground, so the grass hides their bottoms)
    FOREACH(Tomb, t, tombs) {
        Sprite s = (t.type == 0) ? sprTombRound : (t.type == 1 ? sprTombCross : sprTombSlab);
        DrawSpr(s, t.x - s.w / 2, GV - s.h + 3 + t.dy, false, ToColor(Lerp3((Vector3){ 255, 255, 255 }, vSkyBottom, 0.18f), 1.0f, 255));
    }
}

static void DrawGround(void) {
    // Dirt first (brown, a little tinted by the weather), then grass hanging over it.
    Vector3 dirt = Lerp3((Vector3){ 84, 52, 44 }, vGround, 0.18f);
    DrawRectangle(0, GV,      VW, VH - GV,  ToColor(dirt, 1.0f, 255));
    DrawRectangle(0, GV + 16, VW, VH - GV,  ToColor(dirt, 0.80f, 255));
    DrawRectangle(0, GV + 25, VW, VH - GV,  ToColor(dirt, 0.62f, 255));

    // Pebbles and small stones in the dirt
    FOREACH(Grass, g, grass) {
        float shade = (g.shade == 0) ? 1.55f : (g.shade == 1 ? 0.55f : 1.2f);
        DrawRectangle(g.x, g.y, g.h + 1, g.h, ToColor(dirt, shade, 255));
        DrawRectangle(g.x, g.y + g.h, g.h + 1, 1, ToColor(dirt, 0.4f, 255));
    }

    // Grass: a solid band, a bright top edge, and blades that drip over the dirt.
    Color gBase = ToColor(vGround, 1.0f, 255), gDark = ToColor(vGround, 0.62f, 255), gLite = ToColor(vGround, 1.55f, 255);
    DrawRectangle(0, GV, VW, 4, gBase);
    for (int x = 0; x < VW; x++) {
        int d = dripLen[x];
        DrawRectangle(x, GV + 4, 1, d - 2, gBase);
        DrawRectangle(x, GV + 2 + d - 1, 1, 1, gDark);          // dark tip on each drip
        if (x % 3 == 0) DrawRectangle(x, GV - 1, 1, 1, gLite);   // blades poking up
        if (x % 7 == 2) DrawRectangle(x, GV - 2, 1, 2, gBase);
    }
    DrawRectangle(0, GV, VW, 1, gLite);
    for (int x = 0; x < VW; x += 2) DrawRectangle(x, GV + 3, 1, 1, gDark);
}

static void DrawFogBand(Fog f) {
    Color c = { 190, 200, 225, 255 };
    int x = (int)f.x, y = (int)f.y;
    DrawEllipse(x, y, f.w * 0.5f,  13, Fade(c, vFogAlpha * 0.5f));
    DrawEllipse(x, y, f.w * 0.36f, 9,  Fade(c, vFogAlpha * 0.6f));
    DrawEllipse(x, y, f.w * 0.22f, 5,  Fade(c, vFogAlpha * 0.7f));
}

static void DrawWeatherParticles(void) {
    WeatherRules R = RULES[weather.type];
    float windVisual = WindPush() * 1.5f;
    for (int i = 0; i < R.particles && i < dropsCount; i++) {
        Drop d = drops[i];
        int x = (int)d.x, y = (int)d.y;
        if (weather.type == W_SNOW) {
            int s = d.size > 1.7f ? 2 : 1;
            DrawRectangle(x, y, s, s, Fade(WHITE, 0.9f));
        } else {
            int dx = (int)(windVisual * 0.02f);
            PixLine(x, y, x + dx, y + 4, 1, Fade((Color){ 150, 180, 230, 255 }, 0.7f));
        }
    }
}

// The hooded Lantern Keeper. The lantern IS the catch zone.
static void DrawPlayer(void) {
    int px = V(player.x);
    int sway = (int)Clampf(-player.vx * 0.018f, -4, 4);        // lantern swings as you move
    int lx = px + sway, ly = GV - 46;                          // lantern position
    float flicker = 0.85f + 0.15f * sinf(totalTime * 17.0f) * sinf(totalTime * 5.3f);
    bool moving = fabsf(player.vx) > 40;

    // Warm light pool: drawn even while blinking so the world never goes fully dark.
    DrawGlow(lx, ly, (int)(60 * flicker), (Color){ 255, 170, 70, 255 }, 0.6f);
    BeginBlendMode(BLEND_ADDITIVE);
    DrawEllipse(px, GV + 3, 60 * flicker, 7, Fade((Color){ 255, 170, 70, 255 }, 0.10f));
    EndBlendMode();

    // Blink while invulnerable (after being hit).
    if (player.invuln > 0 && ((int)(player.invuln * 14) % 2 == 0)) return;

    // Shadow on the ground
    DrawEllipse(px, GV + 2, 12, 3, Fade(BLACK, 0.45f));

    // Body: swap between two walking frames while moving.
    bool frameB = moving && ((int)(totalTime * 7.0f) % 2 == 1);
    int bob = moving ? ((int)(totalTime * 14.0f) % 2) : 0;
    bool faceLeft = player.vx < -40;
    DrawSpr(frameB ? sprPlayerB : sprPlayerA, px - 9, GV - 31 - bob, faceLeft, WHITE);

    // The shepherd's-crook pole: up from the hand, then over to the lantern.
    Color wood = { 104, 74, 48, 255 };
    int poleX = px + (faceLeft ? -11 : 11);
    PixLine(poleX, GV - 14 - bob, poleX, GV - 58, 2, wood);
    PixLine(poleX, GV - 58, lx, GV - 58, 2, wood);
    DrawRectangle(lx, GV - 57, 1, 6, (Color){ 40, 30, 24, 255 });      // chain
    DrawRectangle(poleX - 1, GV - 15 - bob, 3, 3, (Color){ 232, 196, 150, 255 });   // hand

    // The lantern itself, flickering between two frames.
    DrawSprC(((int)(totalTime * 9.0f) % 2) ? sprLanternA : sprLanternB, lx, ly, false, WHITE);

    // Dotted ring that shows the catch zone, so you always know your reach.
    float rx = ((buff[P_WIDE] > 0) ? 150.0f : 88.0f) * 0.25f;   // half the hitbox, on the small canvas
    float ry = 15.5f;
    for (int i = 0; i < 28; i++) {
        float a = i * (6.2832f / 28.0f) + totalTime * 0.6f;
        int ex = lx + (int)(cosf(a) * rx), ey = ly + (int)(sinf(a) * ry);
        bool wide = buff[P_WIDE] > 0;
        DrawRectangle(ex, ey, 1, 1, Fade(wide ? (Color){ 255, 226, 110, 255 } : (Color){ 255, 190, 100, 255 }, wide ? 0.85f : 0.5f));
    }

    // Ward bubble
    if (player.shield) {
        int cy = GV - 16;
        float pulse = 0.6f + 0.25f * sinf(totalTime * 6.0f);
        DrawCircle(px, cy, 22, Fade((Color){ 96, 160, 255, 255 }, 0.12f));
        DrawCircleLines(px, cy, 22, Fade((Color){ 150, 200, 255, 255 }, pulse));
        DrawCircleLines(px, cy, 21, Fade((Color){ 96, 160, 255, 255 }, pulse * 0.5f));
    }
}

// Little embers floating up off a burning thing.
static void DrawEmbers(Item it, int x, int y, Color c, int n) {
    for (int i = 0; i < n; i++) {
        float ph = fmodf(it.spin * 0.45f + i / (float)n, 1.0f);
        int sx = x + (int)(sinf(i * 2.3f + it.spin * 0.9f) * (5 + ph * 4));
        int sy = y + 5 - (int)(ph * 20);
        DrawRectangle(sx, sy, 1, 1, Fade(c, 1.0f - ph));
        if (i % 2 == 0 && ph < 0.5f) DrawRectangle(sx, sy - 1, 1, 1, Fade(WHITE, 0.6f - ph));
    }
}

static void DrawItem(Item it) {
    int x = V(it.pos.x), y = V(it.pos.y);

    if (it.kind == K_SOUL) {
        float f = 0.8f + 0.2f * sinf(it.spin * 2.0f);
        DrawGlow(x, y, (int)(16 * f), it.color, 0.9f);
        DrawEmbers(it, x, y, (Color){ 150, 255, 240, 255 }, 5);
        DrawSprC(((int)(it.spin * 0.8f) % 2) ? sprSoulA : sprSoulB, x, y - 1, false, WHITE);

    } else if (it.kind == K_SKULL) {
        DrawGlow(x, y, 14, it.color, 0.7f);
        DrawSprC(sprSkull, x, y, false, WHITE);

    } else if (it.kind == K_BAT) {
        DrawGlow(x, y, 13, it.color, 0.6f);
        DrawSprC(((int)(it.spin * 0.9f) % 2) ? sprBatA : sprBatB, x, y, false, WHITE);

    } else {   // K_POWER: an orb with an icon inside
        float bobY = sinf(it.spin * 0.8f) * 1.5f;
        int yy = y + (int)bobY;
        float pulse = 0.75f + 0.25f * sinf(it.spin * 1.4f);
        DrawGlow(x, yy, (int)(18 * pulse), it.color, 1.0f);
        DrawCircle(x, yy, 9, Fade((Color){ 12, 10, 24, 255 }, 0.92f));
        DrawCircleLines(x, yy, 9, it.color);
        DrawCircleLines(x, yy, 10, Fade(it.color, 0.4f));
        DrawSprC(PowerSprite(it.power), x, yy, false, WHITE);
    }
}

// The whole world.
static void DrawWorld(void) {
    DrawSky();
    DrawStars();
    DrawMoon();
    DrawClouds();

    // Lightning bolt (solid colours - no see-through lines, to keep it crisp)
    if (flash > 0.12f && boltCount > 1) {
        for (int i = 0; i + 1 < boltCount; i++) {
            PixLine((int)bolt[i].x, (int)bolt[i].y, (int)bolt[i + 1].x, (int)bolt[i + 1].y, 3, (Color){ 150, 110, 230, 255 });
            PixLine((int)bolt[i].x, (int)bolt[i].y, (int)bolt[i + 1].x, (int)bolt[i + 1].y, 1, WHITE);
        }
    }

    DrawScenery();
    DrawGround();

    // Back fog (behind the player)
    for (int i = 0; i < fogsCount; i += 2) DrawFogBand(fogs[i]);

    FOREACH(Item, it, items) DrawItem(it);
    DrawPlayer();
    DrawWeatherParticles();

    // Front fog (in front of the player, makes it feel deeper)
    for (int i = 1; i < fogsCount; i += 2) DrawFogBand(fogs[i]);

    FOREACH(Spark, s, sparks) {
        int sz = s.life > 0.3f ? 2 : 1;
        DrawRectangle((int)s.pos.x, (int)s.pos.y, sz, sz, Fade(s.color, Clampf(s.life * 3, 0, 1)));
    }
    FOREACH(Popup, p, popups) {
        int w = MeasureText(p.text, 10);
        DrawTextShadow(p.text, (int)p.pos.x - w / 2, (int)p.pos.y, 10, Fade(p.color, Clampf(p.life * 3, 0, 1)));
    }
}

// Panel in the top-right showing the weather info.
static void DrawWeatherPanel(void) {
    int x = VW - 110, y = 6, w = 104, h = 38;
    DrawRectangle(x, y, w, h, Fade(BLACK, 0.55f));
    DrawRectangleLines(x, y, w, h, Fade((Color){ 150, 160, 200, 255 }, 0.45f));
    DrawText(RULES[weather.type].name, x + 6, y + 4, 10, (Color){ 225, 230, 245, 255 });

    // Wind speed, plus arrows showing which way it blows (>> = pushes right, << = pushes left).
    float push = WindPush();
    const char* arrows = (fabsf(push) < 3) ? "" : (push > 0 ? (push > 14 ? ">>>" : ">>") : (push < -14 ? "<<<" : "<<"));
    char buf[64];
    snprintf(buf, sizeof(buf), "%.0fC  %.0f km/h %s", weather.tempC, weather.windKmh, arrows);
    DrawText(buf, x + 6, y + 16, 10, (Color){ 180, 190, 215, 255 });

    // Little tag: LIVE (green) / PREVIEW or offline (grey)
    Color tag = weather.live ? (Color){ 90, 220, 120, 255 } : (Color){ 170, 170, 180, 255 };
    DrawRectangle(x + 6, y + 30, 3, 3, tag);
    DrawText(weather.live ? "LIVE" : "NOT LIVE", x + 13, y + 27, 10, tag);
}

// Active power-ups, shown top-centre with a timer bar under each icon.
static void DrawBuffs(void) {
    int active[P_COUNT], n = 0;
    for (int p = P_SHIELD; p < P_COUNT; p++) {
        if (p == P_SHIELD ? player.shield : buff[p] > 0) active[n++] = p;
    }
    int startX = VW / 2 - (n * 28) / 2 + 14;
    for (int i = 0; i < n; i++) {
        int p = active[i], cx = startX + i * 28, cy = 14;
        DrawRectangle(cx - 12, cy - 9, 24, 22, Fade(BLACK, 0.5f));
        DrawSprC(PowerSprite(p), cx, cy - 1, false, WHITE);
        float frac = (p == P_SHIELD) ? 1.0f : Clampf(buff[p] / POWERS[p].duration, 0, 1);
        DrawRectangle(cx - 10, cy + 8, 20, 2, Fade(BLACK, 0.8f));
        DrawRectangle(cx - 10, cy + 8, (int)(20 * frac), 2, POWERS[p].color);
    }
}

static void DrawHUD(void) {
    char buf[64];
    snprintf(buf, sizeof(buf), "%d", score);
    DrawTextShadow(buf, 8, 6, 20, (Color){ 190, 255, 240, 255 });
    DrawTextShadow("SOULS", 9, 28, 10, (Color){ 170, 200, 200, 230 });

    // Chain (combo) - catch souls without missing to raise the multiplier
    int y = 40;
    if (combo >= 2) {
        int mult = 1 + MINV(combo, 20) / 5;
        snprintf(buf, sizeof(buf), "Chain %d (x%d)", combo, mult);
        DrawTextShadow(buf, 9, y, 10, (Color){ 255, 214, 120, 255 });
        y += 12;
    }

    // Lives as pixel flames (dark = lost)
    for (int i = 0; i < MODES[mode].lives; i++)
        DrawSpr(sprFlame, 9 + i * 12, y + 1, false, i < player.lives ? WHITE : (Color){ 50, 50, 70, 200 });
    y += 13;

    if (mode == MODE_HARD) DrawTextShadow("HARD MODE", 9, y, 10, MODES[MODE_HARD].color);

    DrawBuffs();

    // Bottom tip for the current weather
    DrawTextCenteredShadow(RULES[weather.type].tip, VW / 2, VH - 14, 10, (Color){ 235, 235, 245, 255 });
}

static void DrawModeSelector(int y) {
    const char* hint = "(press H to switch)";
    // Both options side by side; the chosen one is bright with brackets.
    int xs[MODE_COUNT] = { VW / 2 - 70, VW / 2 + 22 };
    for (int m = 0; m < MODE_COUNT; m++) {
        bool on = (m == mode);
        Color c = on ? MODES[m].color : (Color){ 120, 120, 140, 255 };
        char buf[32];
        snprintf(buf, sizeof(buf), on ? "[ %s ]" : "  %s  ", MODES[m].name);
        DrawTextShadow(buf, xs[m], y, 10, c);
    }
    DrawTextCenteredShadow(hint, VW / 2, y + 12, 10, (Color){ 150, 155, 175, 255 });
    DrawTextCenteredShadow(MODES[mode].desc, VW / 2, y + 24, 10, (Color){ 215, 220, 235, 255 });
}

static void DrawTitle(void) {
    DrawRectangle(0, 0, VW, VH, Fade(BLACK, 0.5f));
    int bob = (int)(sinf(totalTime * 1.6f) * 2.0f);
    // The title flickers like a dying bulb every so often.
    float flick = (sinf(totalTime * 23.0f) * sinf(totalTime * 7.3f) > 0.88f) ? 0.35f : 1.0f;
    Color title = Fade((Color){ 225, 50, 55, 255 }, flick);
    DrawTextCenteredShadow("THE LANTERN", VW / 2, 14 + bob, 30, title);
    DrawTextCenteredShadow("KEEPER", VW / 2, 44 + bob, 30, title);
    DrawTextCenteredShadow("Catch souls. Dodge the dead. Real weather rules the night.", VW / 2, 84, 10, (Color){ 215, 220, 235, 230 });

    // Live weather status on the menu - shows the web request working.
    char buf[160];
    snprintf(buf, sizeof(buf), "%s - %s %.0fC", weather.status, RULES[weather.type].name, weather.tempC);
    DrawTextCenteredShadow(buf, VW / 2, 100, 10, weather.live ? (Color){ 150, 255, 170, 255 } : (Color){ 255, 220, 150, 255 });
    DrawTextCenteredShadow(RULES[weather.type].tip, VW / 2, 112, 10, WHITE);

    DrawModeSelector(132);

    float pulse = 0.75f + 0.25f * sinf(totalTime * 4.0f);
    DrawTextCenteredShadow("PRESS SPACE TO BEGIN", VW / 2, 170, 20, Fade((Color){ 255, 238, 150, 255 }, pulse));

    // Controls box
    int bx = 104, by = 194, bw = 192, bh = 90;
    DrawRectangle(bx, by, bw, bh, Fade(BLACK, 0.6f));
    DrawRectangleLines(bx, by, bw, bh, Fade((Color){ 150, 160, 200, 255 }, 0.5f));
    DrawTextCenteredShadow("CONTROLS", VW / 2, by + 4, 10, (Color){ 255, 200, 100, 255 });
    const char* keys[7] = { "A/D Arrows", "H", "1 - 5", "R", "P", "M", "N" };
    const char* what[7] = { "Move lantern", "Switch mode", "Preview weather", "Real weather", "Pause", "Mute music", "Mute all sound" };
    for (int i = 0; i < 7; i++) {
        DrawText(keys[i], bx + 8, by + 15 + i * 10, 10, WHITE);
        DrawText(what[i], bx + 84, by + 15 + i * 10, 10, (Color){ 190, 200, 220, 255 });
    }

    if (bestScore[mode] > 0) {
        snprintf(buf, sizeof(buf), "Best (%s): %d", MODES[mode].name, bestScore[mode]);
        DrawTextCenteredShadow(buf, VW / 2, 288, 10, (Color){ 190, 255, 240, 255 });
    }
    // Show the keeper standing in the graveyard on the title screen.
    DrawPlayer();
}

static void DrawGameOver(void) {
    DrawRectangle(0, 0, VW, VH, Fade((Color){ 20, 0, 0, 255 }, 0.65f));
    DrawTextCenteredShadow("YOU WERE CLAIMED", VW / 2, 44, 20, (Color){ 215, 40, 45, 255 });
    char buf[96];
    snprintf(buf, sizeof(buf), "Souls collected: %d", score);
    DrawTextCenteredShadow(buf, VW / 2, 84, 20, (Color){ 210, 245, 240, 255 });
    snprintf(buf, sizeof(buf), "Best (%s): %d%s", MODES[mode].name, bestScore[mode], newBest ? "   NEW BEST!" : "");
    DrawTextCenteredShadow(buf, VW / 2, 114, 10, (Color){ 255, 214, 120, 255 });
    snprintf(buf, sizeof(buf), "You lasted %.0f seconds in the %s", playTime, RULES[weather.type].name);
    DrawTextCenteredShadow(buf, VW / 2, 130, 10, (Color){ 230, 220, 225, 220 });
    DrawModeSelector(152);
    float pulse = 0.75f + 0.25f * sinf(totalTime * 4.0f);
    DrawTextCenteredShadow("SPACE TO RISE AGAIN", VW / 2, 208, 20, Fade((Color){ 255, 200, 100, 255 }, pulse));
}

// ---------------------------------------------------------------------
// 7. FRAME + MAIN
// ---------------------------------------------------------------------

// Runs once per frame (60 times a second): handle input, update, draw.
static void Frame(void) {
    float dt = GetFrameTime();
    if (dt > 0.05f) dt = 0.05f;   // cap so lag doesn't break physics
    totalTime += dt;

    // Weather preview keys + refresh work on every screen.
    if (IsKeyPressed(KEY_ONE))   PreviewWeather(W_CLEAR);
    if (IsKeyPressed(KEY_TWO))   PreviewWeather(W_CLOUDY);
    if (IsKeyPressed(KEY_THREE)) PreviewWeather(W_RAIN);
    if (IsKeyPressed(KEY_FOUR))  PreviewWeather(W_SNOW);
    if (IsKeyPressed(KEY_FIVE))  PreviewWeather(W_STORM);
    if (IsKeyPressed(KEY_R))     FetchWeather();

    // H switches between Normal and Hard (not mid-run).
    if (IsKeyPressed(KEY_H) && gameState != STATE_PLAYING) { mode = (mode == MODE_NORMAL) ? MODE_HARD : MODE_NORMAL; PlaySfx(SFX_TICK, 1.0f, 1.0f); }
    // M = music on/off (button in the bottom-right corner too). N = ALL sound on/off.
    {
        Vector2 mp = GetMousePosition();
        bool clicked = IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && mp.x / 2 >= VW - 70 && mp.x / 2 <= VW - 4 && mp.y / 2 >= VH - 17 && mp.y / 2 <= VH - 4;
        if (IsKeyPressed(KEY_M) || clicked) { musicMuted = !musicMuted; ApplyMusicVolume(); }
        if (IsKeyPressed(KEY_N)) { muted = !muted; if (audioOK) SetMasterVolume(muted ? 0.0f : 0.8f); }
    }
    // P pauses.
    if (IsKeyPressed(KEY_P) && gameState == STATE_PLAYING) paused = !paused;

    // State machine: what happens depends on which screen we're on.
    switch (gameState) {
        case STATE_TITLE:
            if (IsKeyPressed(KEY_SPACE)) { ResetGame(); gameState = STATE_PLAYING; PlaySfx(SFX_START, 1.0f, 1.0f); }
            break;
        case STATE_PLAYING:
            if (!paused) UpdatePlaying(dt);
            break;
        case STATE_GAMEOVER:
            if (IsKeyPressed(KEY_SPACE)) { ResetGame(); gameState = STATE_PLAYING; PlaySfx(SFX_START, 1.0f, 1.0f); }
            break;
    }
    UpdateVisuals(dt);
    if (!paused) UpdateEffects(dt);
    UpdateAudio(dt);

    // ---- Draw everything onto the small canvas ----
    BeginDrawing();
    ClearBackground(BLACK);

    BeginTextureMode(canvas);
    ClearBackground(BLACK);
    DrawWorld();

    // Screen-wide effects: lightning flash, hurt flash, vignette.
    if (flash > 0)    DrawRectangle(0, 0, VW, VH, Fade((Color){ 200, 210, 255, 255 }, flash * 0.30f));
    if (hitFlash > 0) DrawRectangle(0, 0, VW, VH, Fade((Color){ 220, 0, 0, 255 }, hitFlash * 0.40f));
    DrawVignette(0.45f, BLACK);
    // Heartbeat: when you're on your last flame, the edges pulse red.
    if (gameState == STATE_PLAYING && player.lives == 1) {
        float beat = 0.5f + 0.5f * sinf(totalTime * 7.0f);
        DrawVignette(0.20f + 0.35f * beat, (Color){ 170, 0, 0, 255 });
    }

    // UI is drawn last so it sits on top.
    if (gameState != STATE_TITLE) DrawWeatherPanel();   // the title screen shows the weather in its own text
    if (gameState == STATE_PLAYING)  DrawHUD();
    if (gameState == STATE_TITLE)    DrawTitle();
    if (gameState == STATE_GAMEOVER) { DrawHUD(); DrawGameOver(); }
    {   // little music button, bottom-right (click it or press M)
        const char* lbl = muted ? "ALL MUTED (N)" : (musicMuted ? "MUSIC OFF (M)" : "MUSIC ON (M)");
        int bw = MeasureText(lbl, 10) + 8, bx = VW - 4 - bw, by = VH - 17;
        DrawRectangle(bx, by, bw, 13, Fade(BLACK, 0.55f));
        DrawRectangleLines(bx, by, bw, 13, Fade((Color){ 150, 160, 200, 255 }, 0.5f));
        DrawText(lbl, bx + 4, by + 2, 10, (muted || musicMuted) ? (Color){ 255, 140, 130, 255 } : (Color){ 190, 255, 220, 255 });
    }
    if (paused) {
        DrawRectangle(0, 0, VW, VH, Fade(BLACK, 0.5f));
        DrawTextCenteredShadow("PAUSED", VW / 2, 120, 30, WHITE);
        DrawTextCenteredShadow("press P to continue", VW / 2, 156, 10, (Color){ 210, 215, 230, 255 });
    }
    EndTextureMode();

    // ---- Stretch the small canvas up to the window (no smoothing = chunky pixels) ----
    // Screen shake just nudges where we place the canvas (in whole 2-pixel steps).
    int ox = shake > 0 ? ((int)RandF(-shake, shake) / 2) * 2 : 0;
    int oy = shake > 0 ? ((int)RandF(-shake, shake) / 2) * 2 : 0;
    DrawTexturePro(canvas.texture, (Rectangle){ 0, 0, (float)VW, -(float)VH },          // negative height = flip (render textures are upside down)
                   (Rectangle){ (float)ox, (float)oy, (float)SCREEN_W, (float)SCREEN_H }, (Vector2){ 0, 0 }, 0.0f, WHITE);
    EndDrawing();
}

// Sets everything up. (Separate from main() so it is easy to reuse.)
static void GameInit(void) {
    InitWindow(SCREEN_W, SCREEN_H, "The Lantern Keeper");
    SetTargetFPS(60);

    canvas = LoadRenderTexture(VW, VH);
    SetTextureFilter(canvas.texture, TEXTURE_FILTER_POINT);   // POINT = no blurring when stretched

    InitAudio();
    LoadSprites();
    InitVisuals();
    player.x = 90;     // on the title screen the keeper stands on the left
    FetchWeather();    // kick off the web request right away
}

int main(void) {
    GameInit();

#if defined(PLATFORM_WEB)
    // In a browser, we can't use a normal "while" loop - we hand the browser
    // our Frame function and it calls it every frame for us.
    emscripten_set_main_loop(Frame, 0, 1);
#else
    while (!WindowShouldClose()) Frame();
#endif

    CloseWindow();
    return 0;
}
